import { Table } from "next-ts-lib";
import Manage from "@/app/Layouts/Manage";

const headers = [
  { heading: "Role Name", field: "", sort: false },
  { heading: "Description", field: "", sort: false },
];

const ManageRoles = () => {
  return (
    <Manage manageFor="Roles">
      <Table
          data={[]}
          headers={headers}
          actions={[]}
          actionHeading="Actions"
          sticky
          sortable
          action
        />
    </Manage>
  );
};

export default ManageRoles;
