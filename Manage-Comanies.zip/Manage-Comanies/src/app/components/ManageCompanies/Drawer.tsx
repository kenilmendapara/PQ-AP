import { useEffect, useState } from "react";

// Lib components
import {
  Button,
  Close,
  Select,
  Avatar,
  Tel,
  TextField,
  Toast,
} from "next-ts-lib";

// icons
import EditIcon from "@/app/assets/icons/EditIcon";
import axios from "axios";

interface companyDetails {
  Id: number;
  Name: string;
  Address: string;
  Country: string;
  CountryId: number;
  AccToolCompanyId: string;
  AccountingTool: number;
  City: string;
  CityId: number;
  CompanyImage: string;
  CreatedBy: string;
  CreatedOn: string;
  Email: string;
  EntityType: number;
  IntacctCompanyId: string | null;
  IntacctLocationId: string | null;
  IntacctPassword: string | null;
  IntacctUserId: string | null;
  IsActive: boolean;
  Phone: string;
  State: string;
  StateId: number;
  UpdatedBy: string | null;
  UpdatedOn: string | null;
  ZipCode: string;
}

const EntityTypeList = [
  { label: "Profit Organization", value: "0" },
  { label: "Non-profit Organization", value: "1" },
];

const CountryList = [
  { label: "india", value: "0" },
  { label: "china", value: "1" },
  { label: "japan", value: "2" },
];

const StateList = [
  { label: "Gujrat", value: "0" },
  { label: "Rajsthan", value: "1" },
  { label: "Kerala", value: "2" },
];

const CityList = [
  { label: "Rajkot", value: "1" },
  { label: "Surat", value: "2" },
  { label: "Bhuj", value: "3" },
];

interface DrawerProps {
  onOpen: () => void;
  onClose: () => void;
  companyData: any;
  onEdit: boolean;
  accountingTool: number;
}

const Drawer: React.FC<DrawerProps> = ({
  onOpen,
  onClose,
  onEdit,
  companyData,
  accountingTool,
}: any) => {
  const initialFormData = {
    id: 0,
    companyName: "",
    entityType: "",
    address: "",
    country: "",
    state: "",
    city: "",
    postalCode: 0,
    phoneNumber: 0,
    email: "",
    deletedFile: 0,
  };

  const [Id, setId] = useState("");
  const [companyName, setCompanyName] = useState("");
  const [companyNameError, setCompanyNameError] = useState(false);
  const [companyNameHasError, setCompanyNameHasError] = useState(false);
  const [entityType, setEntityType] = useState(-1);
  const [entityTypeError, setEntityTypeError] = useState(false);
  const [entityTypeHasError, setEntityTypeHasError] = useState(false);
  const [address, setAddress] = useState("");
  const [addressError, setAddressError] = useState(false);
  const [addressHasError, setAddressHasError] = useState(false);
  const [country, setCountry] = useState(-1);
  const [countryError, setCountryError] = useState(false);
  const [countryHasError, setCountryHasError] = useState(false);
  const [state, setState] = useState(-1);
  const [stateError, setStateError] = useState(false);
  const [stateHasError, setStateHasError] = useState(false);
  const [city, setCity] = useState(-1);
  const [cityError, setCityError] = useState(false);
  const [cityHasError, setCityHasError] = useState(false);
  const [zipCode, setZipCode] = useState("");
  const [zipCodeError, setZipCodeError] = useState(false);
  const [zipCodeHasError, setZipCodeHasError] = useState(false);
  const [phone, setPhone] = useState("");
  const [phoneError, setPhoneError] = useState(false);
  const [phoneHasError, setPhoneHasError] = useState(false);
  const [email, setEmail] = useState("");
  const [emailError, setEmailError] = useState(false);
  const [emailHasError, setEmailHasError] = useState(false);
  const [deletedFile, setDeletedFile] = useState("");
  const [deletedFileError, setDeletedFileError] = useState(false);
  const [deletedFileHasError, setDeletedFileHasError] = useState(false);

  useEffect(() => {
    if (companyData && onEdit) {
      setId(companyData?.Id);
      setCompanyName(companyData?.Name);
      setEntityType(companyData?.EntityType);
      setAddress(companyData?.Address);
      setCountry(companyData?.Country);
      setState(companyData?.State);
      setCity(companyData?.City);
      setZipCode(companyData?.ZipCode);
      setPhone(companyData?.Phone);
      setEmail(companyData?.Email);
      setDeletedFile(companyData?.DeletedFile);
    } else {
      setId("");
      setCompanyName("");
      setEntityType(-1);
      setAddress("");
      setCountry(-1);
      setState(-1);
      setCity(-1);
      setZipCode("");
      setPhone("");
      setEmail("");
      setDeletedFile("");
    }
  }, [companyData]);

  const [imagePreview, setImagePreview] = useState<string>("");
  // const [selectedFile, setSelectedFile] = useState(null);
  // const [fileName, setFileName] = useState("");

  const handleSubmit = async (e: { preventDefault: () => void }) => {
    e.preventDefault();

    companyName.trim().length <= 0 && setCompanyNameError(true);
    entityType <= -1 && setEntityTypeError(true);
    address.trim().length <= 0 && setAddressError(true);
    country <= -1 && setCountryError(true);
    state <= -1 && setStateError(true);
    city <= -1 && setCityError(true);
    zipCode.trim().length <= 0 && setZipCodeError(true);
    phone.trim().length <= 0 && setPhoneError(true);
    email.trim().length <= 0 && setEmailError(true);
    deletedFile.trim().length <= 0 && setDeletedFileError(true);

    if (
      companyNameError &&
      entityTypeError &&
      addressError &&
      countryError &&
      stateError &&
      cityError &&
      zipCodeError &&
      phoneError &&
      emailError &&
      deletedFileError
    ) {
      saveCompany();
    } else if (onEdit) {
      saveCompany();
    }
  };

  const saveCompany = async () => {
    try {
      const accessToken = localStorage.getItem("accessToken");
      const headers = {
        Authorization: accessToken,
      };
      const response = await axios.post(
        "https://pq-ap-adminfunctions.azurewebsites.net/api/company/save",
        {
          Id: Id || 0,
          Name: companyName,
          EntityType: entityType,
          Address: address,
          Country: country,
          State: state,
          City: city,
          ZipCode: zipCode,
          Phone: phone.substring(4),
          Email: email,
          AccountingTool: accountingTool,
          // IsActive: true,
          // "CountryId": 1,
          // "StateId": 1,
          // "CityId": 1,
          // "CompanyImage": "01C4DC19-7E78-47AA-A18E-D722CA1A7BE8",
          // "AccToolCompanyId": null,
          // "CreatedBy": 46,
          // "UpdatedBy": null,
          // IntacctUserId: null,
          // IntacctPassword: null,
          // IntacctCompanyId: null,
          // IntacctLocationId: null,
        },
        { headers: headers }
      );

      if (response.status === 200) {
        if (response.data.ResponseStatus === "Success") {
          Toast.success("Success");
          onClose();
        } else {
          onClose();
          const data = response.data.Message;
          if (data === null) {
            Toast.error("Error", "Please try again later.");
          } else {
            Toast.error("Error", data);
          }
        }
      } else {
        onClose();
        const data = response.data.Message;
        if (data === null) {
          Toast.error("Error", "Failed Please try again.");
        } else {
          Toast.error("Error", data);
        }
      }
    } catch (error) {
      console.error(error);
    }
  };

  const onUploadImage = (e: any) => {
    if (e.target?.files && e.target.files[0]) {
      const file = e.target.files[0];
      // setSelectedFile(file);
      // setFileName(file.name);
      const reader = new FileReader();
      reader.onload = function (e) {
        const result = e.target?.result;
        if (result && typeof result === "string") {
          setImagePreview(result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleEditIconClick = () => {
    const fileInput = document.getElementById("imageUpload");
    fileInput && fileInput.click();
  };
  if (!onOpen) return null;

  return (
    <>
      {/* Toast */}
      <div className="z-50">
        <Toast position="top_center" />
      </div>

      {/*  Drawer */}
      <div
        className={`fixed right-0 top-0 h-screen overflow-y-auto lg:w-5/12 text-black transform bg-white z-[999] ${
          onOpen ? "translate-x-0" : "translate-x-full"
        } transition-transform duration-500 ease-in-out`}
      >
        <div className="flex justify-between py-[13px] border-b-[1px] border-[#D8D8D8] ">
          <div className="text-black text-[18px] mx-6 font-bold">
            {/* Add Company */}
            {onEdit ? "Edit Company" : "Add Company"}
          </div>
          <div onClick={onClose} className="mx-3">
            <Close variant="medium" />
          </div>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="mx-6">
            <div className="relative flex mt-5">
              <Avatar
                variant="large"
                className="!opacity-100"
                imageUrl={imagePreview}
              />
              <div
                className="absolute bottom-0 left-11 cursor-pointer bg-[#EEF4F8] rounded p-0.5"
                onClick={handleEditIconClick}
              >
                <EditIcon />
              </div>
              <input
                type="file"
                id="imageUpload"
                accept=".png, .jpg, .jpeg"
                className="hidden"
                onChange={onUploadImage}
              />
            </div>
            <div className=" text-black text-[16px] font-bold mt-7">
              Company Details
            </div>
            <div className="grid lg:grid-cols-2 md:grid-cols-1 mt-2">
              <div className="lg:w-56 md:w-full">
                <TextField
                  label="Company Name"
                  className=""
                  type="text"
                  maxChar={100}
                  value={companyName}
                  getValue={(e) => setCompanyName(e)}
                  getError={(e) => setCompanyNameError(e)}
                  hasError={companyNameHasError}
                  validate
                ></TextField>
              </div>
              <div className="lg:w-56 md:w-full lg:mx-6 md:mx-0">
                <Select
                  id=""
                  className="!pt-[2px]"
                  type="icons"
                  defaultValue={entityType}
                  options={EntityTypeList}
                  label="Entity Type"
                  getValue={(e) => setEntityType(e)}
                  validate
                />
              </div>
            </div>
            <div className="text-black text-[16px] font-bold mt-7">
              Address Details
            </div>
            <div className="mt-2">
              <TextField
                label="Address"
                className="!pt-0"
                type="text"
                maxChar={200}
                value={address}
                getValue={(e) => setAddress(e)}
                getError={(e) => setAddressError(e)}
                hasError={addressHasError}
                validate
              ></TextField>
            </div>
            <div className="grid lg:grid-cols-2 md:grid-cols-1 lg:mt-4 md:mt-2">
              <div className="lg:w-56 md:w-full">
                <Select
             placeholder="Select Country"
                  type="icons"
                  value={country}
                  options={CountryList}
                  label="Country"
                 
                  validate
                />
              </div>
              <div className="lg:w-56 md:w-full lg:mx-5 md:mx-0">
                <Select
                  // id={companyData.id.toString()}
                  type="icons"
                  defaultValue={state}
                  options={StateList}
                  label="State"
              
                  validate
                />
              </div>
            </div>
            <div className="grid lg:grid-cols-2 md:grid-cols-1 lg:mt-4 md:mt-2">
              <div className="lg:w-56 md:w-full">
                <Select
                  // id={companyData.id.toString()}
                  type="icons"
                  options={CityList}
                  defaultValue={city}
                  label="City"
                  validate
                />
              </div>
              <div className="lg:w-56 md:w-full lg:mx-5 md:mx-0 lg:mt-1.5">
                <TextField
                  type="icons"
                  label="Zip/Postal Code"
                  getValue={(e) => setZipCode(e)}
                  getError={(e) => setZipCodeError(e)}
                  hasError={zipCodeHasError}
                  validate
                  className="!p-0"
                />
              </div>
            </div>
            <div className="grid lg:grid-cols-2 md:grid-cols-1 lg:mt-4">
              <div className="lg:w-56 md:w-full md:mt-2 !pt-[2px]">
                <Tel
                  className="lg:!pt-1.5"
                  validate
                  required
                  label="Phone Number"
                  max={12}
                  getValue={(e) => setPhone(e.slice(4))}
                  getError={(e) => setPhoneError(e)}
                  // hasError={setPhoneHasError}
                  countryCode     
                />
              </div>
              <div className="lg:w-56 md:w-full lg:mx-5 md:mt-2 md:mx-0">
                <TextField
                  type="icons"
                  label="Email Address"
                  value={email}
                  maxChar={100}
                  getValue={(e) => setEmail(e)}
                  getError={(e) => setEmailError(e)}
                  // hasError={setEmailHasError}
                  validate
                />
              </div>
            </div>
            <div className=" text-black text-[16px] font-bold mt-7">
              Other Details
            </div>
            <div className="grid lg:grid-cols-2 md:grid-cols-1 mt-1">
              <div className="lg:w-56 md:w-full">
                <TextField
                  label="Delete File in Days"
                  className="!pt-0"
                  type="text"
                  id="delete"
                  validate
                  getValue={(e) => setDeletedFile(e)}
                  getError={(e) => setDeletedFileError(e)}
                  hasError={deletedFileHasError}
                ></TextField>
              </div>
            </div>
          </div>
          <div className="w-full flex justify-end mt-8 border-t-[1px] py-3.5 px-2 border-[#D8D8D8] bottom-0">
            <div>
              <Button
                className="rounded-full btn-sm font-semibold mx-2 !w-24 !h-[36px]"
                variant="btn-outline-primary"
                onClick={onClose}
              >
                CANCEL
              </Button>
            </div>
            <div>
              <Button
                type="submit"
                className="rounded-full btn-sm mx-2 font-semibold !w-20 !h-[36px]"
                variant="btn-primary"
              >
                SAVE
              </Button>
            </div>
          </div>
        </form>
      </div>
    </>
  );
};

export default Drawer;
