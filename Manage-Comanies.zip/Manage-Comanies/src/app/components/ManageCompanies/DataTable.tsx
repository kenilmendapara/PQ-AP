import React, { useEffect } from "react";
import { Table } from "next-ts-lib";
import AssignUser from "./AssignUser";
import ImageList from "./ImageList";
import axios from "axios";

// const headers = [
//   { heading: "Id", field: "id", sort: false },
//   { heading: "Company", field: "title", sort: false },
//   { heading: "Connected with", field: "thumbnail", sort: false },
//   { heading: "Modified Date", field: "price", sort: false },
//   { heading: "Assign user", field: "category", sort: false },
// ];

const headers = [
  { heading: "Id", field: "Id", sort: true },
  { heading: "Company", field: "Name", sort: true },
  { heading: "Connected with", field: "AccountingTool", sort: true },
  { heading: "Modified Date", field: "UpdatedOn", sort: true },
  { heading: "Assign user", field: "status", sort: true },
];

const DataTable = ({ onAction }: any) => {
  const getCompanyList = async () => {
    try {
      const accessToken = localStorage.getItem("accessToken");
      const headers = {
        Authorization: accessToken,
      };
      const body = {
        Name: "PGSL Development",
        AccountingTool: 3,
      };

      const response = await axios.post(
        "https://pq-ap-adminfunctions.azurewebsites.net/api/company/getlist",
        body,
        { headers: headers }
      );

      if (response.status === 200) {
        console.log(response.data.ResponseData);
      } else {
        console.error("Failed to Retriving Company List");
      }
    } catch (error) {
      console.log(error);
    }
  };

  // useEffect(() => {
  //   getCompanyList();
  // }, []);

  const jsondata = [
    {
      id: 1,
      name: <ImageList name="Kenil" imageUrl="https://picsum.photos/200" />,
      email: (
        <ImageList
          name="QuickBook"
          imageUrl="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSv26TvCWusuQWjAAuncGhTg094aGaTBr9x1w&usqp=CAU"
        />
      ),
      company: "Acme Inc.",
      role: ["Admin", "Developer"],
      status: "Active",
    },
    {
      id: 2,
      name: <ImageList name="Mihir" imageUrl="https://picsum.photos/200" />,
      email: (
        <ImageList
          name="Xero"
          imageUrl="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAYFBMVEUatNf///8AsNUArtQAsdX0+/2Bz+X4/f6m3OzJ6vPs+PvW7/aG0ebE6PLd8vi95fFWwt5kxuBFvtwtuNlyy+Pj9Pm14u+X1+nY8PdAvNuk2uuQ1ehdxN96zeRuyeK44/CHJmafAAAOXUlEQVR4nOWdbYOqKhCACWhNbcuybHs9//9fXkxBkBnA0lLvfDlndw15YmAGGAay+IREy2Mab4vV6lLKalVs4/S4/MirF2TY4pO0uD72hFPGKOWcVlL+p/yZ7B/XIk2GrcJwhJt/64yzkofgUqIykq3/HQerxzCE6Skjgs2BZoGS7JQOUpf+CTerTKhkMFwjojWz1ab3+vRMGP8Qp1b6G5Os436r1CdhfCfsHbwakvF7n5C9ER7XvAc8CUmuvQ09PREW55e6Hi6U7Yt+qtYHYbLuMGx2gKTXPkzl+4TpbhC+inH393XCeN9b74OEs+xdK/keYbwfqvkaofv3GN8hTPdscL5SWPaOrr5OmOw+w/dkfLw+5rxMuH7Ld+kqnF4/TFiQ4Ttgi5FsP0h4zD6noI3Q7CVVfYXw9A0+Uqrq5SOEx/OnFbQReu7urnYmvHypAWthq4EJlx8w8R7ELBqS8PejJgIWzrvNHjsRrr+roVJYJ9vYgTD6uoZKoV00NZxwQ76voVI4CR9Tgwm3Y2nASuhv34TfsvKoBJuNQML72ABFK/70SZiNS0Urobv+CEcziJrCs54Io3w8g6gp9BxgNfyE4wUUrRiA6CUcM6BAzL2IPsJxA5at+C7hyAEDED2E+7EDlk7qO4SjtINt4W676CQ8TAHQ5924CEfni2JCXT6qg3A7FUDhhjtmGjjhZhoqWgnF54soYfTtSneU7oQTsBO64F44Rrieko6WQk/dCH+nM8pIYcgiI0y4nFoLPgV2wmHCiXXCSpCuCBJeJtmEyOIURHicXieshEEbjBDh+ds1fVn2YYSnaepoKZCe2oST1dFSAD21CfffruU7wm9+wmLKTQjtZ1iE367i2+IjnJw/2hbe9k9bhMm0dbSU9mDTItxN0V0zhR9chOn0m1A04sZBOGlLIaVlMQzCeOrDTCUsRQmn65CakmGEM2lCYfZThHAWvbAUoydqhLMYSCthR5BwBrZQim4TG8LjXHphKZpj0xBO3iPVRVs9bQjnBCj01CYs5kVItxbhbExFLVmbcDMfU1EJTVqEsxpnSlFjjSScjy1UYhLGc1PSxjmtCe/za0O+NgjnB0ikmpK5KqlS04rwZ45tWB9ZrAi/XZlhJG8IJxU6Ey5VkM2T8DJHJRWj6UoRZt+uyzBSBS0+Cec4kpbCJeEsbUUpdFMTItvanhRP5qNw7ohn7ivGKKM8sCgunoSLEoUwVpUVWKuqIxKsG/JznKS7oEGWk22yuVuPUpofVvExiaLkGK8OBE0QwsmuCkYWn7ifimJlhSZzmv8UaRItFlGSFj95IOSzIxLMGlYB4iFnKusTAVfzrYycWhGRxxMBS6MP8cfkLBr8JOd0plbRfNXaMTte8rCeVRGC1lDuFvsR1ZEHnZDuwZjW3zNQXGWYE6ZvbWorDjQDA9ZiqCiLInkS/gMJ5bfmQ2zOdDS7HpSgMbtbKxmDnKoaLa4akRP01K9dlE3x+yRcQ0pNVcFuRO3Qivodu2OVKqUdHs+hWK1r/RBzBqkffM1YfnsEs/fN/o1rgUMDXMnHmCeBRWtVDyTM66I8J0V9C4TlUEOwuSFtFsZxRA3wV+mVN6lcapQHEC5vdZ28p31TD2JeEmLBCQGIOqAsheu1SoqfTHSl/Hb91YM/N/qXahLGl8NuL42BMYLGp8c+z/eHk9Exj267wSJBiH4NXkQNULlF+ib6NlPWWRj+h7app29zaYTRD9d8Az3+/u8hLb2w/PyuvcTdiqI6xKHLT0NVyRV4CALUQpLilsniLGuqrL20Idxw/S1aVPMxM10mznZN8/5zDTd0Kwihysu/N61oPwUB8mboe9gv5lro4EFVWRGa5x+0pEIn24XRi7K9Ke25iyB8ODTZgQgB1sZbSJKDr9UOJ9uEplPUHLq74Z5QJXj9y6+cuDcsUEQQUBnRBH2jMkJKuRSh8SBT6b2wY9ZUbWW74g8yQegCRBFBQFV9x3mb5iiddIEkoRHXylUL4QcEm1Z0zODzBYk8FgVEBAGb7z1zKD6TmZBkGgpJ+KtXRI2jjlGiObLmGk8XxHu0AkCEAVWU9crpTKkogvpnSbjSvxapDX9hReGBQDQi/qBnC1EH1L4fWqfj9GiF0uXau5aE+oxJ7W+6Y5hUUQWqNDQhPr/HRkRakNA6QffJMz2VQVn1lqUk1L0KugA011HUEm0mtiEhgVAaorBNcAs2muWbf6vBpv5REnL7CXMIKRcJTNOoHkQNAk1JUN4ZvRUJ3IKlca2+d6/as7qEasNLEmo7C/JXiV43TgqhJMuVkQiIRraKmzWPCa7CCCICqIzhvVxLcgr7p/cegFAqnz74NKborP1WdlhUnemWrIIIdcRa2kFi4JEcp1TVggjrHn3Q6qbcJcPayk1CNNyJFiT0FFcb0eq/dNFV/mGEMhgm176/uP25SuqWRcdvHk7YQrQHqHzRVdaYlsqi9HfoH6T2W7Fa81U4oe7rQq6gNwWHJZwghLIorR8YQbGalZTN3QuhnikFmBJD58ac8vARRhqhEbut2YY+Cc1UMLa/2LENo0fLLwW0VCM0+oA+OPZH2M51YyPWf1gGSBJflel2jDRa4fqSRmr7whFmEQThKozQTubTRmT175/7Jx7R93wga1G/6wa4OQvD0+H10ix61keMpWH2EMpW1Foqlt9y11BjiLBeaTKccbXobziwtbeP+p7CHgb5NLoviq3ASfci0IVoyrYJae30/BkrU1XG6+RmzCMTz0uFTxPilxqzCYYgSvcC9/ORwoF+KLcFcuNBtr/fz+aqmxzAUcURfmnA3KI1XaJ3GFEOd66lLah0m1CNWu1Bor15KhsbD3AWcwv/GQRrPqgjap+mde/xzam5eQ0NRKiOhHi+LPml4vNIMT/0hugDE14YUaqpJ8KK7jZRqq0vQYRKTd1ndtXGDT66iTm+b50GXjaEEeXvcrCk+qNVN25GfFBL5bzPuail3EjHuVAaEY8iIEsWIKKcA7uObvBasZrFE5hQrni7EgEpP8elNL71UmxNBkGUDzvm+fXw3oy4IKFa9HF8W1w+4jram3vWvFFAc2dK7csobASRqw2zjYewWRI+wvmLea5m3C5NvgnCA/53ByDcis089Q/aZKd7VV6z7gQTartYS+iiEC3Tnms0eu5b4KvK0Aao/hKgFUlz5d+hHUTEtWiL2D2WPotvVkVW7c0nSpqrkpzG4Ln3hO4fOlvw+Z6mFX/qB/Q8jZubxsgpuydgrTBCfToWnbTrsigj2h0JkWvgrvYPMZPvacHn55tWlIhUn6oml4yUEwnGyK7QXPel8R6M0MwZFK/P5V2DjO+vxjHfs9MWPPeAET/S24JtRDmhbeXeSNI4/jOX4QxAnNDOarlMkvYUxw1YTukIOj32tmALUR5o0IYTWI5mETghoWfPTZ6JL71qjsfTKJ/Ws4bdIKppNifOC5rakxkHofij8x4E77yojqcBB1M1kvkW6ZvhplkBc0QyLa39fSchYXdUI5YP77SojokC49rkbqd/F0K1ov47AufbjKCgg/rziOeBXS4DFWXXrYprAw1K7VOEhA/XiOYMhpKTtcq/ge+IqtYs8FyinK+t2KjNT1CIKatiE2Hfm64jewYKC90tgSkaZftLqlQs+V2jca90dTw6029Rll/jpCnqGhpCW8eXIhv9lJ9Dr63iyKOU0Xz/uB92e+KMqC4jnD2vKG+mPWe7W3bucEntUxEdcd49CUcCt18rq9vjMs57RskUTFGx+jM7qN6IOm8x2zMzD0XYdRF3IlItiD8JZ5USo5HKL/ufnD+Ew/WnLsYZ0lme7aJ/GuH8z3LP8Tw+Nc/jz9CtkRtFvp3+6YqKtKn/dcXiTlJ4O7fJpLMHQ2Llp5l/jiF4tWa60mx7NBFxM7MXC5twVmMNh/K1JXMipEuAsGuUyJiFa+d0NcIZJTRDcl/OZzHDuKdMJww4XDINoRuEcC5W39zCNAhnMsMwE3qb+bxn0RNbtwWahLMYTlt3sLXy6s/AJvJWzor23QjTH07p0knYzjIzPbHuX5vdHSXW4SSLMOg84njFvl/OvivIFek3egHulbUJJz3YtIcZkDAwPGGUwgobZ1b3roH3A0KEk70wKPjuPE9ShNEKBXQUu8NykuMpcj83TIge5xu1gCjYXbIT3DJlSMwndh/w5K55hC8hdRBOrStSuBO6CCd2LzeeDQC/sXtSQTYcT1mBE07p5mpslPEQTufiY8gdDSJUZyhGLuzqgnASTuOSKzuxTAdCR7a00QhwQW4XQt+pm+8L9WUc8RGOHZF7U6p4CSPf0aKvCvdnVPESmpmnRiZeFQ0iFIo61uHGr6KBhGP1wqlnFO1AuAjLr/9hYQ9/xYMJx+jduD2ZzoTjW5xy+qKvEI7tKl334dKXCBfHERlGmoenMAwnHJGTytAlizcJF6dxdEZ00el9wkXc31HCl8VzVPxNwkUEpw//oOCLav0QfvvOWR5sJF4nXCRQMpUPCcs6p4F9gbC0/t/pjRzeXBqAsJX37lPCdp4sGT0SLha/cGqjAYXmwV5ML4SlbfwkI7cCgYYnXCytNEkD8t1fUtA3CZ9pkj7Cx3beO4MGIlws0iz8IrtX+ejNe73SgISC8Taoror2+/NXYlBCMasarj+K/veOfvZFKMacU2gSlE5C+en18aWRPggX5eVVwSlVwoTTzHPnWqj0RCj8nFNwWpwAvNzOUPSq9EYo5G+N38QZLqKI9bujiy59EgpJr3n4/axQ49H82ifeondCIcdix4OvjtXpxKd2RW/KqaR/wlI2qwdh4Y1Z3qlLHqv3LDsmwxCWkvyedjnz3AQsGo6xfHf67b/tpAxH+JRos7383PLySmRa3qBcSflf8TPJs5/LdpiWa2RgQilRsknjbVGsSimKbZxurDSWA8l/ahKafzBrzV0AAAAASUVORK5CYII="
        />
      ),
      company: "Tech Corp",
      role: ["Editor", "User"],
      status: "Active",
    },
    {
      id: 3,
      name: <ImageList name="Alvish" imageUrl="https://picsum.photos/200" />,
      email: (
        <ImageList
          name="QuickBook"
          imageUrl="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSv26TvCWusuQWjAAuncGhTg094aGaTBr9x1w&usqp=CAU"
        />
      ),
      company: "Acme Inc.",
      role: ["Admin", "Developer"],
      status: "Active",
    },
    {
      id: 4,
      name: <ImageList name="Devesh" imageUrl="https://picsum.photos/200" />,
      email: (
        <ImageList
          name="Xero"
          imageUrl="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAYFBMVEUatNf///8AsNUArtQAsdX0+/2Bz+X4/f6m3OzJ6vPs+PvW7/aG0ebE6PLd8vi95fFWwt5kxuBFvtwtuNlyy+Pj9Pm14u+X1+nY8PdAvNuk2uuQ1ehdxN96zeRuyeK44/CHJmafAAAOXUlEQVR4nOWdbYOqKhCACWhNbcuybHs9//9fXkxBkBnA0lLvfDlndw15YmAGGAay+IREy2Mab4vV6lLKalVs4/S4/MirF2TY4pO0uD72hFPGKOWcVlL+p/yZ7B/XIk2GrcJwhJt/64yzkofgUqIykq3/HQerxzCE6Skjgs2BZoGS7JQOUpf+CTerTKhkMFwjojWz1ab3+vRMGP8Qp1b6G5Os436r1CdhfCfsHbwakvF7n5C9ER7XvAc8CUmuvQ09PREW55e6Hi6U7Yt+qtYHYbLuMGx2gKTXPkzl+4TpbhC+inH393XCeN9b74OEs+xdK/keYbwfqvkaofv3GN8hTPdscL5SWPaOrr5OmOw+w/dkfLw+5rxMuH7Ld+kqnF4/TFiQ4Ttgi5FsP0h4zD6noI3Q7CVVfYXw9A0+Uqrq5SOEx/OnFbQReu7urnYmvHypAWthq4EJlx8w8R7ELBqS8PejJgIWzrvNHjsRrr+roVJYJ9vYgTD6uoZKoV00NZxwQ76voVI4CR9Tgwm3Y2nASuhv34TfsvKoBJuNQML72ABFK/70SZiNS0Urobv+CEcziJrCs54Io3w8g6gp9BxgNfyE4wUUrRiA6CUcM6BAzL2IPsJxA5at+C7hyAEDED2E+7EDlk7qO4SjtINt4W676CQ8TAHQ5924CEfni2JCXT6qg3A7FUDhhjtmGjjhZhoqWgnF54soYfTtSneU7oQTsBO64F44Rrieko6WQk/dCH+nM8pIYcgiI0y4nFoLPgV2wmHCiXXCSpCuCBJeJtmEyOIURHicXieshEEbjBDh+ds1fVn2YYSnaepoKZCe2oST1dFSAD21CfffruU7wm9+wmLKTQjtZ1iE367i2+IjnJw/2hbe9k9bhMm0dbSU9mDTItxN0V0zhR9chOn0m1A04sZBOGlLIaVlMQzCeOrDTCUsRQmn65CakmGEM2lCYfZThHAWvbAUoydqhLMYSCthR5BwBrZQim4TG8LjXHphKZpj0xBO3iPVRVs9bQjnBCj01CYs5kVItxbhbExFLVmbcDMfU1EJTVqEsxpnSlFjjSScjy1UYhLGc1PSxjmtCe/za0O+NgjnB0ikmpK5KqlS04rwZ45tWB9ZrAi/XZlhJG8IJxU6Ey5VkM2T8DJHJRWj6UoRZt+uyzBSBS0+Cec4kpbCJeEsbUUpdFMTItvanhRP5qNw7ohn7ivGKKM8sCgunoSLEoUwVpUVWKuqIxKsG/JznKS7oEGWk22yuVuPUpofVvExiaLkGK8OBE0QwsmuCkYWn7ifimJlhSZzmv8UaRItFlGSFj95IOSzIxLMGlYB4iFnKusTAVfzrYycWhGRxxMBS6MP8cfkLBr8JOd0plbRfNXaMTte8rCeVRGC1lDuFvsR1ZEHnZDuwZjW3zNQXGWYE6ZvbWorDjQDA9ZiqCiLInkS/gMJ5bfmQ2zOdDS7HpSgMbtbKxmDnKoaLa4akRP01K9dlE3x+yRcQ0pNVcFuRO3Qivodu2OVKqUdHs+hWK1r/RBzBqkffM1YfnsEs/fN/o1rgUMDXMnHmCeBRWtVDyTM66I8J0V9C4TlUEOwuSFtFsZxRA3wV+mVN6lcapQHEC5vdZ28p31TD2JeEmLBCQGIOqAsheu1SoqfTHSl/Hb91YM/N/qXahLGl8NuL42BMYLGp8c+z/eHk9Exj267wSJBiH4NXkQNULlF+ib6NlPWWRj+h7app29zaYTRD9d8Az3+/u8hLb2w/PyuvcTdiqI6xKHLT0NVyRV4CALUQpLilsniLGuqrL20Idxw/S1aVPMxM10mznZN8/5zDTd0Kwihysu/N61oPwUB8mboe9gv5lro4EFVWRGa5x+0pEIn24XRi7K9Ke25iyB8ODTZgQgB1sZbSJKDr9UOJ9uEplPUHLq74Z5QJXj9y6+cuDcsUEQQUBnRBH2jMkJKuRSh8SBT6b2wY9ZUbWW74g8yQegCRBFBQFV9x3mb5iiddIEkoRHXylUL4QcEm1Z0zODzBYk8FgVEBAGb7z1zKD6TmZBkGgpJ+KtXRI2jjlGiObLmGk8XxHu0AkCEAVWU9crpTKkogvpnSbjSvxapDX9hReGBQDQi/qBnC1EH1L4fWqfj9GiF0uXau5aE+oxJ7W+6Y5hUUQWqNDQhPr/HRkRakNA6QffJMz2VQVn1lqUk1L0KugA011HUEm0mtiEhgVAaorBNcAs2muWbf6vBpv5REnL7CXMIKRcJTNOoHkQNAk1JUN4ZvRUJ3IKlca2+d6/as7qEasNLEmo7C/JXiV43TgqhJMuVkQiIRraKmzWPCa7CCCICqIzhvVxLcgr7p/cegFAqnz74NKborP1WdlhUnemWrIIIdcRa2kFi4JEcp1TVggjrHn3Q6qbcJcPayk1CNNyJFiT0FFcb0eq/dNFV/mGEMhgm176/uP25SuqWRcdvHk7YQrQHqHzRVdaYlsqi9HfoH6T2W7Fa81U4oe7rQq6gNwWHJZwghLIorR8YQbGalZTN3QuhnikFmBJD58ac8vARRhqhEbut2YY+Cc1UMLa/2LENo0fLLwW0VCM0+oA+OPZH2M51YyPWf1gGSBJflel2jDRa4fqSRmr7whFmEQThKozQTubTRmT175/7Jx7R93wga1G/6wa4OQvD0+H10ix61keMpWH2EMpW1Foqlt9y11BjiLBeaTKccbXobziwtbeP+p7CHgb5NLoviq3ASfci0IVoyrYJae30/BkrU1XG6+RmzCMTz0uFTxPilxqzCYYgSvcC9/ORwoF+KLcFcuNBtr/fz+aqmxzAUcURfmnA3KI1XaJ3GFEOd66lLah0m1CNWu1Bor15KhsbD3AWcwv/GQRrPqgjap+mde/xzam5eQ0NRKiOhHi+LPml4vNIMT/0hugDE14YUaqpJ8KK7jZRqq0vQYRKTd1ndtXGDT66iTm+b50GXjaEEeXvcrCk+qNVN25GfFBL5bzPuail3EjHuVAaEY8iIEsWIKKcA7uObvBasZrFE5hQrni7EgEpP8elNL71UmxNBkGUDzvm+fXw3oy4IKFa9HF8W1w+4jram3vWvFFAc2dK7csobASRqw2zjYewWRI+wvmLea5m3C5NvgnCA/53ByDcis089Q/aZKd7VV6z7gQTartYS+iiEC3Tnms0eu5b4KvK0Aao/hKgFUlz5d+hHUTEtWiL2D2WPotvVkVW7c0nSpqrkpzG4Ln3hO4fOlvw+Z6mFX/qB/Q8jZubxsgpuydgrTBCfToWnbTrsigj2h0JkWvgrvYPMZPvacHn55tWlIhUn6oml4yUEwnGyK7QXPel8R6M0MwZFK/P5V2DjO+vxjHfs9MWPPeAET/S24JtRDmhbeXeSNI4/jOX4QxAnNDOarlMkvYUxw1YTukIOj32tmALUR5o0IYTWI5mETghoWfPTZ6JL71qjsfTKJ/Ws4bdIKppNifOC5rakxkHofij8x4E77yojqcBB1M1kvkW6ZvhplkBc0QyLa39fSchYXdUI5YP77SojokC49rkbqd/F0K1ov47AufbjKCgg/rziOeBXS4DFWXXrYprAw1K7VOEhA/XiOYMhpKTtcq/ge+IqtYs8FyinK+t2KjNT1CIKatiE2Hfm64jewYKC90tgSkaZftLqlQs+V2jca90dTw6029Rll/jpCnqGhpCW8eXIhv9lJ9Dr63iyKOU0Xz/uB92e+KMqC4jnD2vKG+mPWe7W3bucEntUxEdcd49CUcCt18rq9vjMs57RskUTFGx+jM7qN6IOm8x2zMzD0XYdRF3IlItiD8JZ5USo5HKL/ufnD+Ew/WnLsYZ0lme7aJ/GuH8z3LP8Tw+Nc/jz9CtkRtFvp3+6YqKtKn/dcXiTlJ4O7fJpLMHQ2Llp5l/jiF4tWa60mx7NBFxM7MXC5twVmMNh/K1JXMipEuAsGuUyJiFa+d0NcIZJTRDcl/OZzHDuKdMJww4XDINoRuEcC5W39zCNAhnMsMwE3qb+bxn0RNbtwWahLMYTlt3sLXy6s/AJvJWzor23QjTH07p0knYzjIzPbHuX5vdHSXW4SSLMOg84njFvl/OvivIFek3egHulbUJJz3YtIcZkDAwPGGUwgobZ1b3roH3A0KEk70wKPjuPE9ShNEKBXQUu8NykuMpcj83TIge5xu1gCjYXbIT3DJlSMwndh/w5K55hC8hdRBOrStSuBO6CCd2LzeeDQC/sXtSQTYcT1mBE07p5mpslPEQTufiY8gdDSJUZyhGLuzqgnASTuOSKzuxTAdCR7a00QhwQW4XQt+pm+8L9WUc8RGOHZF7U6p4CSPf0aKvCvdnVPESmpmnRiZeFQ0iFIo61uHGr6KBhGP1wqlnFO1AuAjLr/9hYQ9/xYMJx+jduD2ZzoTjW5xy+qKvEI7tKl334dKXCBfHERlGmoenMAwnHJGTytAlizcJF6dxdEZ00el9wkXc31HCl8VzVPxNwkUEpw//oOCLav0QfvvOWR5sJF4nXCRQMpUPCcs6p4F9gbC0/t/pjRzeXBqAsJX37lPCdp4sGT0SLha/cGqjAYXmwV5ML4SlbfwkI7cCgYYnXCytNEkD8t1fUtA3CZ9pkj7Cx3beO4MGIlws0iz8IrtX+ejNe73SgISC8Taoror2+/NXYlBCMasarj+K/veOfvZFKMacU2gSlE5C+en18aWRPggX5eVVwSlVwoTTzHPnWqj0RCj8nFNwWpwAvNzOUPSq9EYo5G+N38QZLqKI9bujiy59EgpJr3n4/axQ49H82ifeondCIcdix4OvjtXpxKd2RW/KqaR/wlI2qwdh4Y1Z3qlLHqv3LDsmwxCWkvyedjnz3AQsGo6xfHf67b/tpAxH+JRos7383PLySmRa3qBcSflf8TPJs5/LdpiWa2RgQilRsknjbVGsSimKbZxurDSWA8l/ahKafzBrzV0AAAAASUVORK5CYII="
        />
      ),
      company: "Tech Corp",
      role: ["Editor", "User"],
      status: "Active",
    },
  ];

  // const dummyDataHandler = async () => {
  //   const response = await fetch("https://dummyjson.com/products");
  //   const resData = await response.json();
  //   setDummyData(resData.products);
  // };

  // useEffect(() => {
  //   dummyDataHandler();
  // });

  const Action = [onAction];

  const dummy = {
    status: (item: any) => <AssignUser className="w-44" />,
  };
  return (
    <div>
      <Table
        className={"!h-[440px]"}
        data={jsondata}
        headers={headers}
        actions={Action}
        actionHeading=" "
        sticky
        sortable
        action
        JsxComponents={dummy}
      />
    </div>
  );
};

export default DataTable;
