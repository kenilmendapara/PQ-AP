import { Avatar } from "next-ts-lib";
import React from "react";

interface ImageListProps {
  imageUrl?: string;
  name?: string;
  classname?: string;
}

const ImageList: React.FC<ImageListProps> = ({ imageUrl, name, classname }) => {
  return (
    <div className="flex justify-start items-center w-content p-1">
      {imageUrl && (
        <div className="">
          <Avatar variant="small" imageUrl={imageUrl} />
        </div>
      )}
      <div className="pl-1.5">{name}</div>
    </div>
  );
};

export default ImageList;
