// custom components
import NavbarX from "../components/Navbar/horizontal";
import NavbarY from "../components/Navbar/vertical";

const NavBar = ({ children }: { children: React.ReactNode }) => {
  return (
    <div className="lg:flex">
      <NavbarY />
      <div className="w-full flex flex-col">
        <NavbarX />
        <main>{children}</main>
      </div>
    </div>
  );
};

export default NavBar;
