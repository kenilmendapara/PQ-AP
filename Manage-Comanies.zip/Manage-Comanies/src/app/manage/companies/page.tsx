"use client";
// Layout
import NavBar from "@/app/Layouts/NavBar";

//custom components
import ManageCompanies from "@/app/components/ManageCompanies";

//styles
import "next-ts-lib/dist/index.css";

const Page = () => {
  return (
    <NavBar>
      <ManageCompanies />
    </NavBar>
  );
};

export default Page;
