"use client";
// Layout
import NavBar from "@/app/Layouts/NavBar";

//custom components
import ManageRoles from "@/app/components/ManageRoles";

//styles
import "next-ts-lib/dist/index.css";

const Page = () => {
  return (
    <NavBar>
      <ManageRoles />
    </NavBar>
  );
};

export default Page;
