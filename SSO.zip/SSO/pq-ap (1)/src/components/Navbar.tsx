/* eslint-disable react-hooks/rules-of-hooks */
"use client";
import Image from "next/image";
import axios from "axios";
import { useEffect, useRef, useState } from "react";
import CandyBox from "../assets/Icons/CandyBox";
import HelpIcon from "../assets/Icons/HelpIcon";
import PQLogo from "../assets/Icons/PQLogo";
import ATSIcon from "../assets/Icons/Product Icons/ATSIcon";
import APIcon from "../assets/Icons/Product Icons/ApIcon";
import BIIcon from "../assets/Icons/Product Icons/BIIcon";
import DMSIcon from "../assets/Icons/Product Icons/DMSIcon";
import HelpVector from "../assets/Icons/VectorHelp";
import LogoutVector from "../assets/Icons/VectorLogout";
import NewVector from "../assets/Icons/VectorNew";
import { Avatar, Radio, Typography, Tooltip } from "next-ts-lib";
import "next-ts-lib/dist/index.css";

interface ProfileData {
  first_name: string;
  last_name: string;
  phone: string;
  email: string;
  address: string;
  country_id: string;
  state_id: string;
  city_id: string;
  postal_code: string;
  time_zone: string;
  products: Product[];
}

interface Product {
  name: string;
}

const page = () => {
  const toggleRef = useRef<HTMLDivElement>(null);

  const [toggleCandyBoxChange, setToggleCandyBoxChange] =
    useState<boolean>(false);
  const [toggleHelpChange, setToggleHelpChange] = useState<boolean>(false);
  const [toggleProfileChange, setToggleProfileChange] =
    useState<boolean>(false);
  const [selectedProduct, setSelectedProduct] = useState<string | null>(null);
  const [profileData, setProfileData] = useState<ProfileData | null>(null);

  const getProfileData = async () => {
    const token = await localStorage.getItem("token");
    try {
      const config = {
        headers: {
          Authorization: `bearer ${token}`,
        },
      };
      const response = await axios.get(
        "https://pq-sso-uat.azurewebsites.net/api/user/getuserprofile",
        config
      );
      const data = response.data.ResponseData;
      setProfileData(data);
    } catch (error) {
      console.error(error);
    }
  };
  const handleRadioChange = (productId: string) => {
    setSelectedProduct(productId);
  };
  const handleToggleChange = (productId: string) => {
    productId === "CandyBox" && setToggleCandyBoxChange(!toggleCandyBoxChange);
    productId === "Help" && setToggleHelpChange(!toggleHelpChange);
    productId === "ProfileMenu" && setToggleProfileChange(!toggleProfileChange);
  };

  const productData = profileData?.products.map((product, index) => (
    <div className="pt-3 flex justify-center" key={index}>
      <div
        className={`text-sm -ml-2 ${
          selectedProduct === `${product.name}` ? "text-primary" : ""
        }`}
      >
        <Radio
          id={`${product.name}`}
          name="products"
          label={`${product.name}`}
          onChange={() => handleRadioChange(`${product.name}`)}
        />
      </div>
    </div>
  ));

  useEffect(() => {
    getProfileData();
    const handleClickOutside = (event: MouseEvent) => {
      if (
        toggleRef.current &&
        !toggleRef.current.contains(event.target as Node)
      ) {
        setToggleCandyBoxChange(false);
        setToggleHelpChange(false);
        setToggleProfileChange(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <div>
      <nav className="w-full flex items-center justify-between flex-wrap p-2 border-b border-b-lightSilver">
        <div className="flex items-center flex-shrink-0 text-white  ml-3">
          <PQLogo />
        </div>

        <div className="w-auto flex-grow lg:flex lg:items-center lg:w-auto justify-end flex gap-1.5 mr-4 absolute  right-[2%]">
          <div
            className="w-8 h-8 flex items-center justify-center cursor-pointer"
            onClick={() => handleToggleChange("CandyBox")}
          >
            <Tooltip content="PathQuest Apps" position="left">
              <CandyBox />
            </Tooltip>
          </div>
          <div
            className="w-8 h-8 flex items-center justify-center cursor-pointer"
            onClick={() => handleToggleChange("Help")}
          >
            <div>
              <HelpIcon />
            </div>
          </div>
          <div
            className="w-8 h-8 flex items-center justify-center cursor-pointer"
            onClick={() => handleToggleChange("ProfileMenu")}
          >
            {profileData ? <Avatar
                    imageUrl=""
                    name={`${profileData?.first_name || ""} ${profileData?.last_name || ""} `}
                    variant="small"
                  /> : <Avatar
                    imageUrl=""
                    variant="small"
                  />}
          </div>
        </div>
      </nav>

      {/* CandyBox List Group */}
      <div className="flex absolute z-50  right-[105px] -mt-3 " ref={toggleRef}>
        <div
          className={`${
            toggleCandyBoxChange
              ? "visible flex justify-center items-center"
              : "hidden"
          } w-fit h-auto p-4 border border-lightSilver rounded-md bg-white shadow-md`}
        >
          <div className="w-52 h-auto">
            <ul className="w-52">
              <li className="flex w-full px-3 py-2 border-b  border-b-lightSilver hover:bg-lightGray">
                <APIcon bgColor={"white"} />
                <div className="flex justify-center items-center ml-2">
                  <Typography type="label" className="inline-block text-xs">
                    Accounts Payable
                  </Typography>
                </div>
              </li>
              <li className="flex w-auto px-3 py-2 border-b  border-b-lightSilver hover:bg-lightGray">
                <div className=" ">
                  <BIIcon bgColor={"white"} />
                </div>
                <div className="flex justify-center items-center ml-2 ">
                  <Typography type="label" className="inline-block text-xs">
                    Business Intelligence
                  </Typography>
                </div>
              </li>
              <li className="flex w-auto px-3 py-2 border-b  border-b-lightSilver hover:bg-lightGray">
                <div className=" ">
                  <Image
                    src="/tmsIcon.svg"
                    alt="Logo"
                    width={50}
                    height={50}
                    priority
                  />
                </div>
                <div className="flex justify-center items-center ml-3 ">
                  <Typography type="label" className="inline-block text-xs">
                    Time Management System
                  </Typography>
                </div>
              </li>
              <li className="flex w-auto px-3 py-2 border-b  border-b-lightSilver hover:bg-lightGray">
                <div className=" ">
                  <DMSIcon bgColor={"white"} />
                </div>
                <div className="flex justify-center items-center ml-2 ">
                  <Typography type="label" className="inline-block text-xs">
                    Document Management System
                  </Typography>
                </div>
              </li>
              <li className="flex w-auto px-3 py-2  hover:bg-lightGray">
                <div className=" ">
                  <ATSIcon bgColor={"white"} />
                </div>
                <div className="flex justify-center items-center ml-2 ">
                  <Typography type="label" className="inline-block text-xs">
                    Applicant Tracking System
                  </Typography>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Help List Group */}
      <div className="flex absolute z-50 right-[68px] -mt-3 " ref={toggleRef}>
        <div
          className={`${
            toggleHelpChange
              ? "visible flex justify-center items-center"
              : "hidden"
          } w-fit h-auto py-2 border border-lightSilver rounded-md bg-white shadow-md`}
        >
          <div className="w-40 h-auto">
            <ul className="w-40">
              <li className="flex w-full h-9 px-3 hover:bg-lightGray">
                <div className="flex justify-center items-center ">
                  <NewVector />
                </div>
                <div className="flex justify-center items-center ml-2">
                  <Typography type="label" className="inline-block text-xs">
                    What&rsquo;s new
                  </Typography>
                </div>
              </li>
              <li className="flex w-full h-9 px-3 hover:bg-lightGray">
                <div className="flex justify-center items-center ">
                  <HelpVector />
                </div>
                <div className="flex justify-center items-center ml-2">
                  <Typography type="label" className="inline-block text-xs">
                    Help on this page
                  </Typography>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Profile Menu List Group */}
      <div className="flex absolute z-50 right-6 -mt-3" ref={toggleRef}>
        <div
          className={`${
            toggleProfileChange
              ? "visible flex justify-center items-center"
              : "hidden"
          } w-fit h-auto pt-4 border border-lightSilver rounded-md bg-white shadow-md`}
        >
          <div className="w-[220px] h-auto">
            <ul className="w-[220px]">
              <li className="flex w-full px-3 pt-2 pb-3 border-b  border-b-lightSilver">
                <div className="flex flex-col justify-center items-start ml-2">
                  <Typography
                    type="label"
                    className="inline-block text-sm font-light opacity-60"
                  >
                    Signed in as
                  </Typography>
                  <Typography
                    type="label"
                    className="inline-block text-base font-semibold"
                  >
                    {profileData?.first_name} {profileData?.last_name}
                  </Typography>
                </div>
              </li>
              <li className="flex w-auto h-12 px-3 py-2 border-b border-b-lightSilver hover:bg-lightGray hover:text-primary">
                <div className="flex justify-center items-center ml-2 ">
                  <Typography
                    type="label"
                    className="inline-block text-sm font-normal"
                  >
                    My Profile
                  </Typography>
                </div>
              </li>
              <li className="flex w-auto h-12 px-3 py-2 border-b border-b-lightSilver hover:bg-lightGray hover:text-primary">
                <div className="flex justify-center items-center ml-2 ">
                  <Typography
                    type="label"
                    className="inline-block text-sm font-normal"
                  >
                    Manage User
                  </Typography>
                </div>
              </li>
              <li className="flex w-full px-3 pt-2 pb-3 border-b  border-b-lightSilver">
                <div className="flex flex-col justify-center items-start ml-2">
                  <Typography
                    type="label"
                    className="inline-block text-base font-semibold"
                  >
                    Default Settings
                  </Typography>
                  {productData}
                </div>
              </li>
              <li className="flex w-full h-12 px-3 hover:bg-lightGray rounded-b-md group">
                <div className="flex justify-center items-center ml-3">
                  <LogoutVector />
                </div>
                <div className="flex justify-center items-center ml-2 group-hover:text-[#FB2424] ">
                  <Typography
                    type="label"
                    className="inline-block text-sm font-normal"
                  >
                    Logout
                  </Typography>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default page;
