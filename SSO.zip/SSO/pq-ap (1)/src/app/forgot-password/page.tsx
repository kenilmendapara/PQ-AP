"use client";
import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Button, TextField, Typography } from "next-ts-lib";
import BackArrow from "../../assets/Icons/BackArrow";
import "next-ts-lib/dist/index.css";
import Footer from "@/components/Footer";

export default function ForgetPassword() {
  const router = useRouter();
  const [forgetValue, setForgetValue] = useState("");
  const [error, setError] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) {
      router.push("/profile");
    }
  }, []);

  const submit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (forgetValue.trim() === "") {
      setError(true);
    } else {
      setError(false);
      router.push("/forgot-confirm");
      router.push(`/forgot-confirm/?forgetValue=${forgetValue}`);
    }
  };

  return (
    <>
      <div className="h-full forgetWrapper flex items-center flex-col pt-5">
        <Image src="/logo.png" alt="Logo" width={194} height={100} priority />
        <Typography type="h3" className="pt-14 pb-2 font-bold">
          Forget Password
        </Typography>
        <form
          className="text-start w-full max-w-md py-5 px-3 flex flex-col items-center justify-center"
          onSubmit={submit}
        >
          <div className="pb-2 w-[354px]">
            <TextField
              label="Email"
              type="email"
              id="email"
              name="email"
              validate
              getValue={(e) => setForgetValue(e)}
              hasError={error}
            />
          </div>

          <Button
            type="submit"
            variant="btn-primary"
            className="rounded-full !font-semibold mt-[20px] sm:!w-[356px] !w-[256px]"
          >
            SEND EMAIL
          </Button>

          <div className="backLoignWrapper pt-5 flex justify-center">
            <Link href="signin">
              <div className="backArrow items-center justify-center flex">
                <BackArrow />
                <div className="ml-2.5">
                  <Typography
                    type="text"
                    className="!text-[14px] !font-normal text-primary"
                  >
                    Back to Login
                  </Typography>
                </div>
              </div>
            </Link>
          </div>
        </form>
      </div>
      <span className="absolute bottom-0 left-0 w-full">
        <Footer />
      </span>
    </>
  );
}
