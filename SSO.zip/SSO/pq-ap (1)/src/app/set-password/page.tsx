"use client";
import { useEffect, useState } from "react";
import Image from "next/image";
import { Button, Password, Toast, Typography } from "next-ts-lib";
import "next-ts-lib/dist/index.css";
import Footer from "@/components/Footer";
import { useRouter, useSearchParams } from "next/navigation";
import axios from "axios";

export default function SetNewPassword() {
  const getToken = useSearchParams();
  const token = getToken.get("token");
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [cPassword, setCPassword] = useState("");
  const [passwordError, setPasswordError] = useState(false);
  const [passwordErrorMsg, setPasswordErrorMsg] = useState("");
  const [cPasswordError, setCPasswordError] = useState(false);
  const [cPasswordErrorMsg, setCPasswordErrorMsg] = useState("");
  const [error, setError] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) {
      router.push("/profile");
    }
  }, []);

  const submit = async (e: any) => {
    e.preventDefault();
    if (password === "") {
      setPasswordError(true);
      setPasswordErrorMsg("This is required field");
    }
    if (cPassword === "") {
      setCPasswordError(true);
      setCPasswordErrorMsg("This is required field");
    }
    if (password !== cPassword) {
      setError(true);
    } else {
      setError(false);
    }
    if (password !== "" && cPassword !== "" && password === cPassword) {
      try {
        const response = await axios.post(
          "https://pq-sso-uat.azurewebsites.net/api/auth/setpassword",
          {
            token: token,
            password: password,
          }
        );

        if (response.status === 200) {
          if (response.data.ResponseStatus === "Success") {
            router.push(`/signin`);
          } else {
            const data = response.data.Message;
            Toast.error(data);
          }
        } else {
          const data = response.data.Message;
          throw new Error(data || "Please try again.");
        }
      } catch (error) {}
    }
  };
  return (
    <>
      <div className="min-h-screen loginWrapper flex items-center flex-col pt-5">
        <Toast position="top_right" />
        <Image src="/logo.png" alt="Logo" width={194} height={100} priority />
        <div className="flex flex-col items-center justify-center min-h-[80vh]">
          <span className="pb-[25px] text-primary font-bold text-2xl mx-5 sm:mx-auto">
            Please set a new password for your account.
          </span>
          <form
            className="text-start w-full max-w-md py-5 px-3 flex flex-col items-center justify-center"
            onSubmit={submit}
          >
            <div className="pb-4 w-[356px]">
              <Password
                label="New Password"
                name="password"
                getValue={(e) => setPassword(e)}
                hasError={passwordError}
                validate
                errorMessage={passwordErrorMsg}
              />
            </div>
            <div className="pb-4 w-[356px]">
              <Password
                label="Confirm Password"
                getValue={(e) => setCPassword(e)}
                hasError={cPasswordError}
                name="ConfirmpPassword"
                validate
                errorMessage={cPasswordErrorMsg}
              />
            </div>
            {error && (
              <span className="text-defaultRed text-[12px] sm:text-[14px]">
                Password does not match!
              </span>
            )}

            <Button
              type="submit"
              variant="btn-primary"
              className="rounded-full sm:!w-[356px] !w-[256px] !font-semibold mt-[20px]"
            >
              CONTINUE
            </Button>
          </form>
        </div>
      </div>
      <span className="absolute bottom-0 left-0 w-full">
        <Footer />
      </span>
    </>
  );
}
