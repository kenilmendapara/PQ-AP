"use client";
import { useEffect, useState } from "react";
import Image from "next/image";
import { Button, Password, Typography } from "next-ts-lib";
import "next-ts-lib/dist/index.css";
import Footer from "@/components/Footer";
import { useRouter } from "next/navigation";

export default function SetNewPassword() {
  const router = useRouter();
  const [newPassword, setNewpassword] = useState("");
  const [cPassword, setCPassword] = useState("");
  const [passwordError, setPasswordError] = useState(false);
  const [passwordErrorMsg, setPasswordErrorMsg] = useState("");
  const [cPasswordError, setCPasswordError] = useState(false);
  const [cPasswordErrorMsg, setCPasswordErrorMsg] = useState("");

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) {
      router.push("/profile");
    }
  }, []);

  const submit = (e: any) => {
    e.preventDefault();
    if (newPassword === "") {
      setPasswordError(true);
      setPasswordErrorMsg("This is required field");
    }
    if (cPassword === "") {
      setCPasswordError(true);
      setCPasswordErrorMsg("This is required field");
    } else if (newPassword != cPassword) {
      setCPasswordError(true);
      setCPasswordErrorMsg("Password Doesn't matched!");
    }
  };
  return (
    <>
      <div className="min-h-[86vh] sm:min-h-[90.4vh] loginWrapper flex items-center flex-col pt-5">
        <Image src="/logo.png" alt="Logo" width={194} height={100} priority />
        <Typography type="h3" className="pt-[51px] pb-12 font-bold ">
          Forgot Password
        </Typography>
        <form
          className="text-start w-full max-w-md py-5 px-3 flex flex-col items-center justify-center"
          onSubmit={submit}
        >
          <div className="pb-4 w-[354px]">
            <Password
              label="New Password"
              name="newPassword"
              getValue={(e) => setNewpassword(e)}
              hasError={passwordError}
              validate
              errorMessage={passwordErrorMsg}
            />
          </div>
          <div className="w-[354px]">
            <Password
              label="Confirm Password"
              getValue={(e) => setCPassword(e)}
              hasError={cPasswordError}
              name="ConfirmpPassword"
              validate
              errorMessage={cPasswordErrorMsg}
            />
          </div>

          <Button
            type="submit"
            variant="btn-primary"
            className="rounded-full w-full !font-semibold mt-[20px] sm:!w-[356px] !w-[256px]"
          >
            RESET PASSWORD
          </Button>
        </form>
      </div>
      <span className="absolute bottom-0 left-0 w-full">
        <Footer />
      </span>
    </>
  );
}
