"use client";
import Image from "next/image";
import Link from "next/link";
import {
  Button,
  CheckBox,
  Tel,
  TextField,
  Toast,
  Tooltip,
  Typography,
} from "next-ts-lib";
import Google from "../../assets/Icons/Google";
import Apple from "../../assets/Icons/Apple";
import Qb from "../../assets/Icons/Qb";
import Xero from "../../assets/Icons/Xero";
import "next-ts-lib/dist/index.css";
import Footer from "@/components/Footer";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import axios from "axios";

export default function SignUp() {
  const router = useRouter();
  const [fName, setFName] = useState("");
  const [fNameError, setFNameError] = useState(false);
  const [lName, setLName] = useState("");
  const [lNameError, setLNameError] = useState(false);
  const [email, setEmail] = useState("");
  const [emailError, setEmailError] = useState(false);
  const [phone, setPhone] = useState("");
  const [phoneError, setPhoneError] = useState(false);
  const [checked, setChecked] = useState(false);
  const [checkedError, setCheckedError] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem("token")
    if(token){
      router.push("/profile");
    }
  }, [])

  const handleSubmit = async (e: { preventDefault: () => void }) => {
    e.preventDefault();
    fName.trim().length <= 0 && setFNameError(true);
    lName.trim().length <= 0 && setLNameError(true);
    email.trim().length <= 0 && setEmailError(true);
    phone.trim().length <= 0 && setPhoneError(true);
    checked === false && setCheckedError(true);

    if (
      fName.trim() !== "" &&
      lName.trim() !== "" &&
      email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/) &&
      phone.length === 16 &&
      checked
    )
      try {
        const response = await axios.post(
          "https://pq-sso-uat.azurewebsites.net/api/auth/register",
          {
            first_name: fName,
            last_name: lName,
            email: email,
            phone: phone,
          }
        );

        if (response.status === 200) {
          if (response.data.ResponseStatus === "Success") {
            router.push(`/email-activation?email=${encodeURIComponent(email)}`);
          } else {
            const data = response.data.Message;
            Toast.error(data);
          }
        } else {
          const data = response.data.Message;
          throw new Error(data || "Registrarion failed. Please try again.");
        }
      } catch (error) {
        console.error(error);
      }
  };

  return (
    <>
      <div className="loginWrapper flex items-center justify-center flex-col pt-5">
        <Toast position="top_right" />
        <Image src="/logo.png" alt="Logo" width={194} height={100} priority />
        <Typography
          type="h3"
          className="pt-5 pb-[10px] !font-bold text-primary"
        >
          Let&rsquo;s Get Started!
        </Typography>
        <span className="text-sm sm:text-base font-normal text-[#1C1C1C]">
          It will take just a few minutes.
        </span>
        <form
          className="text-start w-full max-w-3xl py-5 px-3 flex flex-col items-center justify-center"
          onSubmit={handleSubmit}
        >
          <div className="w-[356px] pb-4">
            <TextField
              label="First Name"
              type="text"
              id="fname"
              name="fname"
              validate
              getValue={(e) => setFName(e)}
              hasError={fNameError}
            />
          </div>
          <div className="w-[356px] pb-4">
            <TextField
              label="Last Name"
              type="text"
              id="lname"
              name="lname"
              validate
              getValue={(e) => setLName(e)}
              hasError={lNameError}
            />
          </div>
          <div className="w-[356px] pb-4">
            <TextField
              label="Email Id"
              type="email"
              id="email"
              name="email"
              validate
              getValue={(e) => setEmail(e)}
              hasError={emailError}
            />
          </div>
          <div className="w-[356px] pb-4">
            <Tel
              label="Phone"
              countryCode
              validate
              getValue={(e) => setPhone(e)}
              hasError={phoneError}
            />
          </div>
          <div className="pt-2 pb-9 flex justify-center items-center">
            <div className="flex items-center justify-center">
              <CheckBox
                id="agree"
                onChange={(e) => setChecked(e.target.checked)}
                hasError={checkedError}
              />
              <span className="text-sm">Agree to all &nbsp;</span>
            </div>
            <Link
              href="#"
              className="underline text-sm text-primary font-semibold"
            >
              Terms & Conditions
            </Link>
          </div>
          <Button
            type="submit"
            variant="btn-primary"
            className="rounded-full sm:!w-[356px] !w-[256px]"
          >
            SIGN UP
          </Button>
        </form>
        <div className="socialMediaBox w-[356px] max-w-md border-t border-lightSilver p-3 pt-5 relative my-3 flex flex-col ">
          <Typography
            type="p"
            className="bg-white relative top-[-25px] px-5 max-w-content m-auto"
          >
            or Continue with
          </Typography>
          <ul className="flex justify-evenly">
            <li>
              <Link href="#">
                <Tooltip content="Google" position="top">
                  <Google />
                </Tooltip>
              </Link>
            </li>
            <li>
              <Link href="#">
                <Tooltip content="Apple" position="top">
                  <Apple />
                </Tooltip>
              </Link>
            </li>
            <li>
              <Link href="#">
                <Tooltip content="QuickBooks" position="top">
                  <Qb />
                </Tooltip>
              </Link>
            </li>
            <li>
              <Link href="#">
                <Tooltip content="Xero" position="top">
                  <Xero />
                </Tooltip>
              </Link>
            </li>
          </ul>
        </div>
        <div className="mb-10">
          Already have an account?&nbsp;
          <Link href="/signin" className="text-primary font-semibold underline">
            Sign In
          </Link>
        </div>
      </div>
      <Footer />
    </>
  );
}
