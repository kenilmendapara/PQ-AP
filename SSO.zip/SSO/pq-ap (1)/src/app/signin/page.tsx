"use client";
import Image from "next/image";
import Link from "next/link";

import {
  Button,
  CheckBox,
  Password,
  TextField,
  Toast,
  Tooltip,
  Typography,
} from "next-ts-lib";
import "next-ts-lib/dist/index.css";
import Google from "../../assets/Icons/Google";
import Apple from "../../assets/Icons/Apple";
import Qb from "../../assets/Icons/Qb";
import Xero from "../../assets/Icons/Xero";
import Footer from "@/components/Footer";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import axios from "axios";

export default function Home() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [emailError, setEmailError] = useState(false);
  const [password, setPassword] = useState("");
  const [passwordError, setPasswordError] = useState(false);
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) {
      router.push("/profile");
    }
  }, []);

  const handleSubmit = async (e: { preventDefault: () => void }) => {
    e.preventDefault();
    email.trim().length <= 0 && setEmailError(true);
    password.trim().length <= 0 && setPasswordError(true);

    if (email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/) && password.trim() !== "") {
      try {
        const response = await axios.post(
          "https://pq-sso-uat.azurewebsites.net/api/auth/token",
          {
            username: email,
            password: password,
          }
        );

        if (response.status === 200) {
          if (response.data.ResponseStatus === "Success") {
            router.push(`/verification?email=${encodeURIComponent(email)}`);
          } else {
            const data = response.data.Message || "Data does not match.";
            Toast.error(data);
          }
        } else {
          const data = response.data.Message;
          throw new Error(data || "Login failed. Please try again.");
        }
      } catch (error) {
        console.error(error);
      }
    }
  };
  return (
    <>
      <div className="min-h-screen loginWrapper flex items-center flex-col pt-5">
        <Toast position="top_right" />
        <Image src="/logo.png" alt="Logo" width={194} height={100} priority />
        <Typography type="h3" className="pt-4 pb-2 font-bold text-primary">
          Sign In
        </Typography>
        <form
          className="text-start w-full max-w-3xl py-5 px-3 flex flex-col items-center justify-center"
          onSubmit={handleSubmit}
        >
          <div className="pb-5 w-[356px]">
            <TextField
              label="Email Id"
              type="email"
              id="email"
              name="email"
              validate
              getValue={(e) => setEmail(e)}
              hasError={emailError}
            />
          </div>
          <div className="pb-5 w-[356px]">
            <Password
              label="Password"
              name="password"
              validate
              getValue={(e) => setPassword(e)}
              hasError={passwordError}
            />
          </div>
          <div className="pb-5 w-[356px] flex justify-between items-center">
            <div className="flex items-center justify-center">
              <CheckBox
                id="agree"
                onChange={(e) => setChecked(e.target.checked)}
              />
              <span>Keep me logged in</span>
            </div>
            <Link
              href="/forgot-password"
              className="text-primary font-semibold"
            >
              Forgot Password?
            </Link>
          </div>
          <Button
            type="submit"
            variant="btn-primary"
            className="rounded-full sm:!w-[356px] !w-[256px] !font-semibold mb-4"
          >
            SIGN IN
          </Button>
        </form>
        <div className="socialMediaBox w-[356px] max-w-md border-t border-lightSilver p-3 relative flex flex-col ">
          <Typography
            type="p"
            className="bg-white relative top-[-25px] px-5 max-w-content m-auto"
          >
            or Continue with
          </Typography>
          <ul className="socialMedia flex justify-around">
            <li>
              <Link href="#">
                <Tooltip content="Google" position="top">
                  <Google />
                </Tooltip>
              </Link>
            </li>
            <li>
              <Link href="#">
                <Tooltip content="Apple" position="top">
                  <Apple />
                </Tooltip>
              </Link>
            </li>
            <li>
              <Link href="#">
                <Tooltip content="QuickBooks" position="top">
                  <Qb />
                </Tooltip>
              </Link>
            </li>
            <li>
              <Link href="#">
                <Tooltip content="Xero" position="top">
                  <Xero />
                </Tooltip>
              </Link>
            </li>
          </ul>
        </div>
        <div className="pb-4 flex justify-between items-center mt-[20px] text-[#333333]">
          Don&rsquo;t have an accout?&nbsp;
          <Link
            href={"/signup"}
            className="text-primary font-semibold underline"
          >
            Sign Up
          </Link>
        </div>
      </div>
      <span className="absolute bottom-0 left-0 w-full">
        <Footer />
      </span>
    </>
  );
}
