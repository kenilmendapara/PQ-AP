"use client";

import Image from "next/image";
import Link from "next/link";
import { Typography } from "next-ts-lib";
import BackArrow from "../../assets/Icons/BackArrow";
import { useSearchParams } from "next/navigation";
import "next-ts-lib/dist/index.css";
import Footer from "@/components/Footer";
import { useRouter } from "next/navigation";
import { useEffect } from "react";

export default function Forgetconfirm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const email = searchParams.get("forgetValue");

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) {
      router.push("/profile");
    }
  }, []);

  return (
    <>
      <div className="min-h-screen  forgetWrapper flex items-center flex-col pt-5">
        <Image src="/logo.png" alt="Logo" width={194} height={100} priority />
        <Typography type="h3" className="pt-14 pb-2 font-bold">
          Check your Email
        </Typography>
        <div className="content tracking-[0.28px] mb-2.5 text-[14px]">
          We&rsquo;ve sent a reset password link to{" "}
          <span className="text-primary"> {email} </span>
        </div>
        <div className="max-w-[450px] xs:!px-5 md:!px-0 tracking-[0.28px] flex justify-center items-center text-center text-[14px]">
          Please use the link provided in the email to reset your password. The
          link is only valid for a limited time. If you did not request this
          change, you can disregard this email and take measures to secure your
          account.
        </div>
        <div className="backLoignWrapper pt-10 flex justify-center ">
          <Link href="signin">
            <div className="backArrow  items-center justify-center flex">
              <BackArrow />
              <div className="ml-2.5  ">
                <Typography
                  type="text"
                  className="!text-[14px] !font-normal text-primary  "
                >
                  Back to Login
                </Typography>
              </div>
            </div>
          </Link>
        </div>
      </div>
      <span className="absolute bottom-0 left-0 w-full">
        <Footer />
      </span>
    </>
  );
}
