import React, { useEffect, useState } from "react";
import { Table } from "next-ts-lib";

// const headers = [
//   { heading: "Id", field: "id", sort: false },
//   { heading: "Company", field: "title", sort: false },
//   { heading: "Connected with", field: "thumbnail", sort: false },
//   { heading: "Modified Date", field: "price", sort: false },
//   { heading: "Assign user", field: "category", sort: false },
// ];

const headers = [
  { heading: "Id", field: "", sort: false },
  { heading: "Company", field: "name", sort: false },
  { heading: "Connected with", field: "email", sort: false },
  { heading: "Modified Date", field: "company", sort: false },
  { heading: "Assign user", field: "status", sort: false },
];

const DataTable = ({ onAction }: any) => {
  
  const [dummyData, setDummyData] = useState([
    {
      name: "John Doe",
      email: "john.doe@example.com",
      company: "Acme Inc.",
      role: ["Admin", "Developer"],
      status: "Active",
    },
    {
      name: "Jane Smith",
      email: "jane.smith@example.com",
      company: "Tech Corp",
      role: ["Editor", "User"],
      status: "Active",
    },
    {
      name: "Bob Johnson",
      email: "bob.johnson@example.com",
      company: "DevCo",
      role: ["Admin", "Manager"],
      status: "Inactive",
    }
  ]);

  // const dummyDataHandler = async () => {
  //   const response = await fetch("https://dummyjson.com/products");
  //   const resData = await response.json();
  //   setDummyData(resData.products);
  // };

  // useEffect(() => {
  //   dummyDataHandler();
  // });

  const Action = [onAction]

  return (
    <div>
      {dummyData.length > 0 && (
        <Table
          data={dummyData}
          headers={headers}
          actions={Action}
          actionHeading=" "
          sticky
          sortable
          action
        />
      )}
    </div>
  );
};

export default DataTable;
