"use client";
import React, { useEffect, useRef, useState } from "react";
import {
  Button,
  Tooltip,
  Select,
  Modal,
  ModalTitle,
  ModalContent,
  ModalAction,
  Close,
  Toast,
  MultiSelect,
} from "next-ts-lib";
import "next-ts-lib/dist/index.css";
import FilterIcon from "../../assets/Icons/List-companies Icons/FilterIcon";
import AddIcon from "../../assets/Icons/List-companies Icons/AddIcon";
import ActionIcon from "../../assets/Icons/List-companies Icons/ActionIcon";
import Drawer from "./Drawer";
import DrawerOverlay from "./DrawerOverlay";
import DataTable from "./DataTable";

const options = [
  { label: "Xero", value: "Xero" },
  { label: "Intacct", value: "Intacct" },
  { label: "QuickBooks Online", value: "QuickBooks Online" },
];

const page: React.FC = () => {
  const filterRef = useRef<HTMLDivElement>(null);

  const [openFilterBox, seOpenFilterBox] = useState<boolean>(false);
  const [openActionBox, setOpenActionBox] = useState<boolean>(false);
  const [openDrawer, setOpenDrawer] = useState<boolean>(false);
  const [openDeactivateModal, setOpenDeactivateModal] =
    useState<boolean>(false);
  const [openDisconnectModal, setOpenDisconnectModal] =
    useState<boolean>(false);
  const [openRemoveModal, setOpenRemoveModal] = useState<boolean>(false);

  const handleOutsideClick = (event: MouseEvent) => {
    if (
      filterRef.current &&
      !filterRef.current.contains(event.target as Node)
    ) {
      seOpenFilterBox(false);
    }
  };

  useEffect(() => {
    window.addEventListener("click", handleOutsideClick);

    return () => {
      window.removeEventListener("click", handleOutsideClick);
    };
  }, []);

  const SuccessToast = () => {
    setTimeout(() => {
      Toast.success("This is success message");
    }, 1000);
  };

  const handleFilterBox = () => {
    seOpenFilterBox(!openFilterBox);
  };

  const handleActionBox = () => {
    setOpenActionBox(!openActionBox);
  };

  const handleDeactivateModal = () => {
    setOpenDeactivateModal(!openDeactivateModal);
  };

  const handleDisconnectModal = () => {
    setOpenDisconnectModal(!openDisconnectModal);
  };

  const handleRemoveModal = () => {
    setOpenRemoveModal(!openRemoveModal);
  };

  const actionButton = (
    <>
      <button type="button" onClick={handleActionBox}>
        <ActionIcon />
      </button>
    </>
  );

  return (
    <>
 
      {/* Toast */}
      <div className="z-50">
        <Toast position="top_center" />
      </div>

      {/* Create companies section */}
      {/* <div className="main flex items-center justify-between w-full px-5 py-[15px]">
        <div className="text-[#333] xs:text-[12px] sm:text-base font-bold">
          <span>Manage Companies</span>
        </div>
        <div className="filter-function flex items-center">
          <div className="cursor-pointer z-10" onClick={handleFilterBox}>
            <Tooltip position="bottom" content="Filter">
              <FilterIcon />
            </Tooltip>
          </div>
          <Button
            type="submit"
            variant="btn-primary"
            className="rounded-[300px]"
          >
            <span className="flex items-center justify-center xs:text-[10px] sm:text-sm">
              <AddIcon />
              <span>CREATE COMPANY</span>
            </span>
          </Button>
        </div>
      </div> */}

      {/*  Drawer */}
      <Drawer onOpen={openDrawer} onClose={() => setOpenDrawer(false)} />

      {/* Drawer Overlay */}
      <DrawerOverlay isOpen={openDrawer} onClose={() => setOpenDrawer(false)} />

      {/* Deactivate Modal Popup */}
      {openDeactivateModal && (
        <div>
          <Modal
            isOpen={handleDeactivateModal}
            onClose={handleDeactivateModal}
            width="352px"
          >
            <ModalTitle>
              <div className="py-3 px-4 font-bold">Deactivate</div>
              <div className="" onClick={handleDeactivateModal}>
                <Close variant="medium" />
              </div>
            </ModalTitle>
            <ModalContent>
              <div className="p-2 mb-3">
                Are you sure you want to deactivate.
              </div>
            </ModalContent>
            <ModalAction>
              <div>
                <Button
                  className="rounded-full btn-sm font-semibold mx-2 my-3 !w-16 !h-[36px]"
                  variant="btn-outline-primary"
                  onClick={handleDeactivateModal}
                >
                  No
                </Button>
              </div>
              <div onClick={SuccessToast}>
                <Button
                  className="rounded-full btn-sm font-semibold mx-2 my-3 !w-16 !h-[36px]"
                  variant="btn-primary"
                  onClick={handleDeactivateModal}
                >
                  Yes
                </Button>
              </div>
            </ModalAction>
          </Modal>
        </div>
      )}

      {/* Disconnect Modal Popup */}
      {openDisconnectModal && (
        <Modal
          isOpen={handleDisconnectModal}
          onClose={handleDisconnectModal}
          width="352px"
        >
          <ModalTitle>
            <div className="py-3 px-4 font-bold">Disconnect</div>
            <div className="" onClick={handleDisconnectModal}>
              <Close variant="medium" />
            </div>
          </ModalTitle>
          <ModalContent>
            <div className="p-2 mb-3">
              Are you sure you want to disconnect the company with accounting
              tool ?
            </div>
          </ModalContent>
          <ModalAction>
            <div>
              <Button
                className="rounded-full btn-sm font-semibold mx-2 my-3 !w-16 !h-[36px]"
                variant="btn-outline-primary"
                onClick={handleDisconnectModal}
              >
                No
              </Button>
            </div>
            <div onClick={SuccessToast}>
              <Button
                className="rounded-full btn-sm font-semibold mx-2 my-3 !w-16 !h-[36px]"
                variant="btn-primary"
                onClick={handleDisconnectModal}
              >
                Yes
              </Button>
            </div>
          </ModalAction>
        </Modal>
      )}

      {/* Remove Modal Popup */}
      {openRemoveModal && (
        <Modal
          isOpen={handleRemoveModal}
          onClose={handleRemoveModal}
          width="352px"
        >
          <ModalTitle>
            <div className="py-3 px-4 font-bold">Remove</div>
            <div className="" onClick={handleRemoveModal}>
              <Close variant="medium" />
            </div>
          </ModalTitle>
          <ModalContent>
            <div className="p-2 mb-3">
              Are you sure you want to remove the Company.
            </div>
          </ModalContent>
          <ModalAction>
            <div>
              <Button
                className="rounded-full btn-sm font-semibold mx-2 my-3 !w-16 !h-[36px]"
                variant="btn-outline-error"
                onClick={handleRemoveModal}
              >
                No
              </Button>
            </div>
            <div onClick={SuccessToast}>
              <Button
                className="rounded-full btn-sm font-semibold mx-2 my-3 !w-16 !h-[36px]"
                variant="btn-error"
                onClick={handleRemoveModal}
              >
                Yes
              </Button>
            </div>
          </ModalAction>
        </Modal>
      )}

      {/* For Filter menu */}
      <div className="flex absolute right-52 z-10 -mt-6">
        <div
          className={`${
            openFilterBox
              ? "visible flex justify-center items-center "
              : "hidden"
          } w-fit h-auto border border-lightSilver rounded-md bg-white shadow-md animate-fade-in-down_1s_ease-in-out`}
        >
          <div className="w-[458px] h-auto">
            <ul className="w-[458px]">
              <li className="flex flex-row justify-between items-center px-4 py-3 border-b border-b-lightSilver">
                <div className="text-black text-[20px] font-[500]">Filter</div>
                <div onClick={handleFilterBox}>
                  <Close variant="medium" />
                </div>
              </li>
              <li className="flex px-4 pt-3 hover:bg-lightGray hover:text-primary">
                <div className="flex justify-center items-center">
                  <div className="inline-block text-sm font-normal">
                    <div className="!w-[425px]">
                      <MultiSelect
                        type="checkbox"
                        label="Company"
                        options={options}
                        defaultValue="All"
                      />
                    </div>
                  </div>
                </div>
              </li>
              <li className="flex px-4 pt-3 hover:bg-lightGray hover:text-primary">
                <div className="flex justify-center items-center">
                  <div className="inline-block text-sm font-normal">
                    <div className="!w-[425px]">
                      <MultiSelect
                        type="checkbox"
                        label="Accounting Tool"
                        options={options}
                        defaultValue="All"
                      />
                    </div>
                  </div>
                </div>
              </li>
              <li className="flex px-4 pt-3 hover:bg-lightGray hover:text-primary">
                <div className="flex justify-center items-center">
                  <div className="inline-block text-sm font-normal">
                    <div className="!w-[425px]">
                      <Select
                        type="icons"
                        label="Assign User"
                        options={options}
                        defaultValue="All"
                      />
                    </div>
                  </div>
                </div>
              </li>
              <li className="flex flex-row justify-end items-center mt-10 px-4 py-3 border-t border-[#D8D8D8]">
                <div>
                  <Button
                    onClick={handleFilterBox}
                    className="rounded-full btn-sm mx-2 font-bold"
                    variant="btn-outline-primary"
                  >
                    CANCEL
                  </Button>
                </div>
                <div onClick={SuccessToast}>
                  <Button
                    className="rounded-full btn-sm mx-2 font-bold"
                    variant="btn-primary"
                    onClick={handleFilterBox}
                  >
                    APPLY
                  </Button>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* For Action menu */}
      <div className="flex absolute mt-24 right-12">
        <div
          className={`${
            openActionBox
              ? "visible flex justify-center items-center"
              : "hidden"
          } w-fit h-auto border border-lightSilver rounded-md bg-white shadow-md`}
        >
          <div className="w-40 h-auto">
            <ul className="w-40">
              <li
                className="flex w-auto h-8 px-5 py-2 hover:bg-lightGray hover:bg-[#ecf7f2] cursor-pointer"
                onClick={() => setOpenDrawer(true)}
              >
                <div className="flex text-sm font-normal justify-center items-center">
                  Edit
                </div>
              </li>
              <li
                className="flex w-auto h-8 px-5 py-2 hover:bg-lightGray hover:bg-[#ecf7f2] cursor-pointer"
                onClick={handleDeactivateModal}
              >
                <div className="flex  text-sm font-normal justify-center items-center">
                  Deactivate
                </div>
              </li>
              <li
                className="flex w-auto h-8 px-5 py-2 hover:bg-lightGray hover:bg-[#ecf7f2] cursor-pointer"
                onClick={handleDisconnectModal}
              >
                <div className="flex  text-sm font-normal justify-center items-center">
                  Disconnect
                </div>
              </li>
              <li
                className="flex w-auto h-8 px-5 py-2 hover:bg-lightGray hover:bg-[#ecf7f2] cursor-pointer"
                onClick={handleRemoveModal}
              >
                <div className="flex  text-sm font-normal justify-center items-center">
                  Remove
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Table Seaction */}
      <DataTable onAction={actionButton} />
    </>
  );
};

export default page;
