/* eslint-disable react-hooks/rules-of-hooks */
"use client";
import React, { useState } from "react";
import ATSIcon from "../../assets/Icons/Product Icons/ATSIcon";
import APIcon from "../../assets/Icons/Product Icons/ApIcon";
import BIIcon from "../../assets/Icons/Product Icons/BIIcon";
import TMSIcon from "../../assets/Icons/Product Icons/TMSIcon";
import DMSIcon from "../../assets/Icons/Product Icons/DMSIcon";
import PMSIcon from "../../assets/Icons/Product Icons/PMSIcon";
import NavBar from "../../components/Navbar";
import { Radio, Typography } from "next-ts-lib";
import "next-ts-lib/dist/index.css";

const page: React.FC = () => {
  const [selectedProduct, setSelectedProduct] = useState<string | null>(null);

  const productId: string[] = ["AP", "BI", "TMS", "DMS", "PMS", "ATS"];
  const productIcon = [APIcon, BIIcon, TMSIcon, DMSIcon, PMSIcon, ATSIcon];
  const productTitle: string[] = [
    "Accounts Payable",
    "Business Intelligence",
    "Time Management System",
    "Document Management System",
    "Project Management System",
    "Applicant Tracking System",
  ];

  const productItems = productId.map((productId, index) => {
    const Icon = productIcon[index];
    return (
      <div
        className={`w-auto h-auto border rounded-lg ${
          selectedProduct === productId
            ? "border-primary"
            : "border-lightSilver"
        } hover:border-primary hover:shadow-lg  group cursor-pointer`}
        onClick={() => handleRadioChange(productId)}
        key={index}
      >
        <div className="h-8 pt-3 pr-5  flex justify-end">
          <div
            className={`${
              selectedProduct === productId ? "opacity-100" : "opacity-0"
            } group-hover:opacity-100 inset-0`}
          >
            <label className="group-hover:text-primary">
              <Radio
                id={productId}
                name="products"
                checked={selectedProduct === productId}
                onChange={() => handleRadioChange(productId)}
              />
            </label>
          </div>
        </div>
        <div className="w-auto h-[65px] pb-3 flex justify-center">
          <Icon bgColor="#F4F4F4" />
        </div>
        <div className="flex pb-5 justify-center">
          <Typography type="label" className="inline-block text-center">
            {productTitle[index]}
          </Typography>
        </div>
      </div>
    );
  });

  const handleRadioChange = (productId: string) => {
    setSelectedProduct(productId);
  };

  return (
    <>
      {/* Navigation Bar */}
      <NavBar />

      {/* Content */}
      <div className="w-auto xs:mx-[30px]  sm:mx-[90px] md:mx-[100px] lg:mx-[138px] py-6 ">
        <Typography type="h4">
          Unleash the Power of Our Top Products - Your Ultimate Solutions!
        </Typography>
        <div className="xs:w-[100%] sm:w-[80%] md:w-[63%] lg:w-[63%] pt-2">
          <Typography type="label" className="inline-block ">
            PathQuest simplifies accounting and financial reporting, delivers
            insights and forecasts, and provides real-time spend insights while
            automating accounts payable invoices and avoiding cash flow crises
            and manual inefficiencies.
          </Typography>
        </div>
      </div>

      {/* Products Grid */}
      <div className="w-auto xs:mx-[30px] xs:mb-[30px] sm:mx-[90px] md:mx-[100px] lg:mx-[138px] grid sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 2xl:grid-cols-6 gap-4">
        {productItems}
      </div>
    </>
  );
};
export default page;
