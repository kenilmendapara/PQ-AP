"use client";

import React, { useEffect, useRef, useState } from "react";
import {
  Button,
  Tooltip,
  Modal,
  ModalTitle,
  ModalContent,
  ModalAction,
  Close,
  Toast,
  MultiSelect,
  Table,
} from "next-ts-lib";

import AddIcon from "@/app/assets/icons/AddIcon";
import ActionIcon from "@/app/assets/icons/ActionIcon";
import Drawer from "./Drawer";
import DrawerOverlay from "./DrawerOverlay";
import DataTable from "./DataTable";
import "next-ts-lib/dist/index.css";
import CompaniesModal from "./CompaniesModal";
import FilterIcon from "@/app/assets/icons/FilterIcon";
import ImageList from "./ImageList";
import AssignUser from "./AssignUser";

const options = [
  { label: "Xero", value: "Xero" },
  { label: "Intacct", value: "Intacct" },
  { label: "QuickBooks Online", value: "QuickBooks Online" },
];

const headers = [
  { heading: "Id", field: "id", sort: true },
  { heading: "Company", field: "name", sort: true },
  { heading: "Connected with", field: "email", sort: true },
  { heading: "Modified Date", field: "company", sort: true },
  { heading: "Assign user", field: "status", sort: true },
];

// const dummyDataHandler = async () => {
//   const response = await fetch("https://dummyjson.com/products");
//   const resData = await response.json();
//   setDummyData(resData.products);
// };

// useEffect(() => {
//   dummyDataHandler();
// });

const ManageCompanies: React.FC = () => {
  const filterMenuRef = useRef<HTMLDivElement>(null);
  const actionMenuRef = useRef<HTMLDivElement>(null);

  const [openFilterBox, setOpenFilterBox] = useState<boolean>(false);
  const [openActionBox, setOpenActionBox] = useState<boolean>(false);
  const [openDrawer, setOpenDrawer] = useState<boolean>(false);
  const [openDeactivateModal, setOpenDeactivateModal] =
    useState<boolean>(false);
  const [openDisconnectModal, setOpenDisconnectModal] =
    useState<boolean>(false);
  const [openRemoveModal, setOpenRemoveModal] = useState<boolean>(false);
  const [openCompaniesModal, setOpenCompaniesModal] = useState<boolean>(false);

  useEffect(() => {
    if (openFilterBox || openActionBox) {
      document.addEventListener("mousedown", handleOutsideClick);
    } else {
      document.removeEventListener("mousedown", handleOutsideClick);
    }
    return () => {
      document.removeEventListener("mousedown", handleOutsideClick);
    };
  }, [openFilterBox, openActionBox]);

  const jsondata = [
    {
      id: 1,
      name: <ImageList name="Kenil" imageUrl="https://picsum.photos/200" />,
      email: (
        <ImageList
          name="QuickBook"
          imageUrl="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSv26TvCWusuQWjAAuncGhTg094aGaTBr9x1w&usqp=CAU"
        />
      ),
      company: "Acme Inc.",
      role: ["Admin", "Developer"],
      status: "Active",
    },
    {
      id: 2,
      name: <ImageList name="Mihir" imageUrl="https://picsum.photos/200" />,
      email: (
        <ImageList
          name="Xero"
          imageUrl="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAYFBMVEUatNf///8AsNUArtQAsdX0+/2Bz+X4/f6m3OzJ6vPs+PvW7/aG0ebE6PLd8vi95fFWwt5kxuBFvtwtuNlyy+Pj9Pm14u+X1+nY8PdAvNuk2uuQ1ehdxN96zeRuyeK44/CHJmafAAAOXUlEQVR4nOWdbYOqKhCACWhNbcuybHs9//9fXkxBkBnA0lLvfDlndw15YmAGGAay+IREy2Mab4vV6lLKalVs4/S4/MirF2TY4pO0uD72hFPGKOWcVlL+p/yZ7B/XIk2GrcJwhJt/64yzkofgUqIykq3/HQerxzCE6Skjgs2BZoGS7JQOUpf+CTerTKhkMFwjojWz1ab3+vRMGP8Qp1b6G5Os436r1CdhfCfsHbwakvF7n5C9ER7XvAc8CUmuvQ09PREW55e6Hi6U7Yt+qtYHYbLuMGx2gKTXPkzl+4TpbhC+inH393XCeN9b74OEs+xdK/keYbwfqvkaofv3GN8hTPdscL5SWPaOrr5OmOw+w/dkfLw+5rxMuH7Ld+kqnF4/TFiQ4Ttgi5FsP0h4zD6noI3Q7CVVfYXw9A0+Uqrq5SOEx/OnFbQReu7urnYmvHypAWthq4EJlx8w8R7ELBqS8PejJgIWzrvNHjsRrr+roVJYJ9vYgTD6uoZKoV00NZxwQ76voVI4CR9Tgwm3Y2nASuhv34TfsvKoBJuNQML72ABFK/70SZiNS0Urobv+CEcziJrCs54Io3w8g6gp9BxgNfyE4wUUrRiA6CUcM6BAzL2IPsJxA5at+C7hyAEDED2E+7EDlk7qO4SjtINt4W676CQ8TAHQ5924CEfni2JCXT6qg3A7FUDhhjtmGjjhZhoqWgnF54soYfTtSneU7oQTsBO64F44Rrieko6WQk/dCH+nM8pIYcgiI0y4nFoLPgV2wmHCiXXCSpCuCBJeJtmEyOIURHicXieshEEbjBDh+ds1fVn2YYSnaepoKZCe2oST1dFSAD21CfffruU7wm9+wmLKTQjtZ1iE367i2+IjnJw/2hbe9k9bhMm0dbSU9mDTItxN0V0zhR9chOn0m1A04sZBOGlLIaVlMQzCeOrDTCUsRQmn65CakmGEM2lCYfZThHAWvbAUoydqhLMYSCthR5BwBrZQim4TG8LjXHphKZpj0xBO3iPVRVs9bQjnBCj01CYs5kVItxbhbExFLVmbcDMfU1EJTVqEsxpnSlFjjSScjy1UYhLGc1PSxjmtCe/za0O+NgjnB0ikmpK5KqlS04rwZ45tWB9ZrAi/XZlhJG8IJxU6Ey5VkM2T8DJHJRWj6UoRZt+uyzBSBS0+Cec4kpbCJeEsbUUpdFMTItvanhRP5qNw7ohn7ivGKKM8sCgunoSLEoUwVpUVWKuqIxKsG/JznKS7oEGWk22yuVuPUpofVvExiaLkGK8OBE0QwsmuCkYWn7ifimJlhSZzmv8UaRItFlGSFj95IOSzIxLMGlYB4iFnKusTAVfzrYycWhGRxxMBS6MP8cfkLBr8JOd0plbRfNXaMTte8rCeVRGC1lDuFvsR1ZEHnZDuwZjW3zNQXGWYE6ZvbWorDjQDA9ZiqCiLInkS/gMJ5bfmQ2zOdDS7HpSgMbtbKxmDnKoaLa4akRP01K9dlE3x+yRcQ0pNVcFuRO3Qivodu2OVKqUdHs+hWK1r/RBzBqkffM1YfnsEs/fN/o1rgUMDXMnHmCeBRWtVDyTM66I8J0V9C4TlUEOwuSFtFsZxRA3wV+mVN6lcapQHEC5vdZ28p31TD2JeEmLBCQGIOqAsheu1SoqfTHSl/Hb91YM/N/qXahLGl8NuL42BMYLGp8c+z/eHk9Exj267wSJBiH4NXkQNULlF+ib6NlPWWRj+h7app29zaYTRD9d8Az3+/u8hLb2w/PyuvcTdiqI6xKHLT0NVyRV4CALUQpLilsniLGuqrL20Idxw/S1aVPMxM10mznZN8/5zDTd0Kwihysu/N61oPwUB8mboe9gv5lro4EFVWRGa5x+0pEIn24XRi7K9Ke25iyB8ODTZgQgB1sZbSJKDr9UOJ9uEplPUHLq74Z5QJXj9y6+cuDcsUEQQUBnRBH2jMkJKuRSh8SBT6b2wY9ZUbWW74g8yQegCRBFBQFV9x3mb5iiddIEkoRHXylUL4QcEm1Z0zODzBYk8FgVEBAGb7z1zKD6TmZBkGgpJ+KtXRI2jjlGiObLmGk8XxHu0AkCEAVWU9crpTKkogvpnSbjSvxapDX9hReGBQDQi/qBnC1EH1L4fWqfj9GiF0uXau5aE+oxJ7W+6Y5hUUQWqNDQhPr/HRkRakNA6QffJMz2VQVn1lqUk1L0KugA011HUEm0mtiEhgVAaorBNcAs2muWbf6vBpv5REnL7CXMIKRcJTNOoHkQNAk1JUN4ZvRUJ3IKlca2+d6/as7qEasNLEmo7C/JXiV43TgqhJMuVkQiIRraKmzWPCa7CCCICqIzhvVxLcgr7p/cegFAqnz74NKborP1WdlhUnemWrIIIdcRa2kFi4JEcp1TVggjrHn3Q6qbcJcPayk1CNNyJFiT0FFcb0eq/dNFV/mGEMhgm176/uP25SuqWRcdvHk7YQrQHqHzRVdaYlsqi9HfoH6T2W7Fa81U4oe7rQq6gNwWHJZwghLIorR8YQbGalZTN3QuhnikFmBJD58ac8vARRhqhEbut2YY+Cc1UMLa/2LENo0fLLwW0VCM0+oA+OPZH2M51YyPWf1gGSBJflel2jDRa4fqSRmr7whFmEQThKozQTubTRmT175/7Jx7R93wga1G/6wa4OQvD0+H10ix61keMpWH2EMpW1Foqlt9y11BjiLBeaTKccbXobziwtbeP+p7CHgb5NLoviq3ASfci0IVoyrYJae30/BkrU1XG6+RmzCMTz0uFTxPilxqzCYYgSvcC9/ORwoF+KLcFcuNBtr/fz+aqmxzAUcURfmnA3KI1XaJ3GFEOd66lLah0m1CNWu1Bor15KhsbD3AWcwv/GQRrPqgjap+mde/xzam5eQ0NRKiOhHi+LPml4vNIMT/0hugDE14YUaqpJ8KK7jZRqq0vQYRKTd1ndtXGDT66iTm+b50GXjaEEeXvcrCk+qNVN25GfFBL5bzPuail3EjHuVAaEY8iIEsWIKKcA7uObvBasZrFE5hQrni7EgEpP8elNL71UmxNBkGUDzvm+fXw3oy4IKFa9HF8W1w+4jram3vWvFFAc2dK7csobASRqw2zjYewWRI+wvmLea5m3C5NvgnCA/53ByDcis089Q/aZKd7VV6z7gQTartYS+iiEC3Tnms0eu5b4KvK0Aao/hKgFUlz5d+hHUTEtWiL2D2WPotvVkVW7c0nSpqrkpzG4Ln3hO4fOlvw+Z6mFX/qB/Q8jZubxsgpuydgrTBCfToWnbTrsigj2h0JkWvgrvYPMZPvacHn55tWlIhUn6oml4yUEwnGyK7QXPel8R6M0MwZFK/P5V2DjO+vxjHfs9MWPPeAET/S24JtRDmhbeXeSNI4/jOX4QxAnNDOarlMkvYUxw1YTukIOj32tmALUR5o0IYTWI5mETghoWfPTZ6JL71qjsfTKJ/Ws4bdIKppNifOC5rakxkHofij8x4E77yojqcBB1M1kvkW6ZvhplkBc0QyLa39fSchYXdUI5YP77SojokC49rkbqd/F0K1ov47AufbjKCgg/rziOeBXS4DFWXXrYprAw1K7VOEhA/XiOYMhpKTtcq/ge+IqtYs8FyinK+t2KjNT1CIKatiE2Hfm64jewYKC90tgSkaZftLqlQs+V2jca90dTw6029Rll/jpCnqGhpCW8eXIhv9lJ9Dr63iyKOU0Xz/uB92e+KMqC4jnD2vKG+mPWe7W3bucEntUxEdcd49CUcCt18rq9vjMs57RskUTFGx+jM7qN6IOm8x2zMzD0XYdRF3IlItiD8JZ5USo5HKL/ufnD+Ew/WnLsYZ0lme7aJ/GuH8z3LP8Tw+Nc/jz9CtkRtFvp3+6YqKtKn/dcXiTlJ4O7fJpLMHQ2Llp5l/jiF4tWa60mx7NBFxM7MXC5twVmMNh/K1JXMipEuAsGuUyJiFa+d0NcIZJTRDcl/OZzHDuKdMJww4XDINoRuEcC5W39zCNAhnMsMwE3qb+bxn0RNbtwWahLMYTlt3sLXy6s/AJvJWzor23QjTH07p0knYzjIzPbHuX5vdHSXW4SSLMOg84njFvl/OvivIFek3egHulbUJJz3YtIcZkDAwPGGUwgobZ1b3roH3A0KEk70wKPjuPE9ShNEKBXQUu8NykuMpcj83TIge5xu1gCjYXbIT3DJlSMwndh/w5K55hC8hdRBOrStSuBO6CCd2LzeeDQC/sXtSQTYcT1mBE07p5mpslPEQTufiY8gdDSJUZyhGLuzqgnASTuOSKzuxTAdCR7a00QhwQW4XQt+pm+8L9WUc8RGOHZF7U6p4CSPf0aKvCvdnVPESmpmnRiZeFQ0iFIo61uHGr6KBhGP1wqlnFO1AuAjLr/9hYQ9/xYMJx+jduD2ZzoTjW5xy+qKvEI7tKl334dKXCBfHERlGmoenMAwnHJGTytAlizcJF6dxdEZ00el9wkXc31HCl8VzVPxNwkUEpw//oOCLav0QfvvOWR5sJF4nXCRQMpUPCcs6p4F9gbC0/t/pjRzeXBqAsJX37lPCdp4sGT0SLha/cGqjAYXmwV5ML4SlbfwkI7cCgYYnXCytNEkD8t1fUtA3CZ9pkj7Cx3beO4MGIlws0iz8IrtX+ejNe73SgISC8Taoror2+/NXYlBCMasarj+K/veOfvZFKMacU2gSlE5C+en18aWRPggX5eVVwSlVwoTTzHPnWqj0RCj8nFNwWpwAvNzOUPSq9EYo5G+N38QZLqKI9bujiy59EgpJr3n4/axQ49H82ifeondCIcdix4OvjtXpxKd2RW/KqaR/wlI2qwdh4Y1Z3qlLHqv3LDsmwxCWkvyedjnz3AQsGo6xfHf67b/tpAxH+JRos7383PLySmRa3qBcSflf8TPJs5/LdpiWa2RgQilRsknjbVGsSimKbZxurDSWA8l/ahKafzBrzV0AAAAASUVORK5CYII="
        />
      ),
      company: "Tech Corp",
      role: ["Editor", "User"],
      status: "Active",
    },
    {
      id: 3,
      name: <ImageList name="Alvish" imageUrl="https://picsum.photos/200" />,
      email: (
        <ImageList
          name="QuickBook"
          imageUrl="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSv26TvCWusuQWjAAuncGhTg094aGaTBr9x1w&usqp=CAU"
        />
      ),
      company: "Acme Inc.",
      role: ["Admin", "Developer"],
      status: "Active",
    },
    {
      id: 4,
      name: <ImageList name="Devesh" imageUrl="https://picsum.photos/200" />,
      email: (
        <ImageList
          name="Xero"
          imageUrl="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAYFBMVEUatNf///8AsNUArtQAsdX0+/2Bz+X4/f6m3OzJ6vPs+PvW7/aG0ebE6PLd8vi95fFWwt5kxuBFvtwtuNlyy+Pj9Pm14u+X1+nY8PdAvNuk2uuQ1ehdxN96zeRuyeK44/CHJmafAAAOXUlEQVR4nOWdbYOqKhCACWhNbcuybHs9//9fXkxBkBnA0lLvfDlndw15YmAGGAay+IREy2Mab4vV6lLKalVs4/S4/MirF2TY4pO0uD72hFPGKOWcVlL+p/yZ7B/XIk2GrcJwhJt/64yzkofgUqIykq3/HQerxzCE6Skjgs2BZoGS7JQOUpf+CTerTKhkMFwjojWz1ab3+vRMGP8Qp1b6G5Os436r1CdhfCfsHbwakvF7n5C9ER7XvAc8CUmuvQ09PREW55e6Hi6U7Yt+qtYHYbLuMGx2gKTXPkzl+4TpbhC+inH393XCeN9b74OEs+xdK/keYbwfqvkaofv3GN8hTPdscL5SWPaOrr5OmOw+w/dkfLw+5rxMuH7Ld+kqnF4/TFiQ4Ttgi5FsP0h4zD6noI3Q7CVVfYXw9A0+Uqrq5SOEx/OnFbQReu7urnYmvHypAWthq4EJlx8w8R7ELBqS8PejJgIWzrvNHjsRrr+roVJYJ9vYgTD6uoZKoV00NZxwQ76voVI4CR9Tgwm3Y2nASuhv34TfsvKoBJuNQML72ABFK/70SZiNS0Urobv+CEcziJrCs54Io3w8g6gp9BxgNfyE4wUUrRiA6CUcM6BAzL2IPsJxA5at+C7hyAEDED2E+7EDlk7qO4SjtINt4W676CQ8TAHQ5924CEfni2JCXT6qg3A7FUDhhjtmGjjhZhoqWgnF54soYfTtSneU7oQTsBO64F44Rrieko6WQk/dCH+nM8pIYcgiI0y4nFoLPgV2wmHCiXXCSpCuCBJeJtmEyOIURHicXieshEEbjBDh+ds1fVn2YYSnaepoKZCe2oST1dFSAD21CfffruU7wm9+wmLKTQjtZ1iE367i2+IjnJw/2hbe9k9bhMm0dbSU9mDTItxN0V0zhR9chOn0m1A04sZBOGlLIaVlMQzCeOrDTCUsRQmn65CakmGEM2lCYfZThHAWvbAUoydqhLMYSCthR5BwBrZQim4TG8LjXHphKZpj0xBO3iPVRVs9bQjnBCj01CYs5kVItxbhbExFLVmbcDMfU1EJTVqEsxpnSlFjjSScjy1UYhLGc1PSxjmtCe/za0O+NgjnB0ikmpK5KqlS04rwZ45tWB9ZrAi/XZlhJG8IJxU6Ey5VkM2T8DJHJRWj6UoRZt+uyzBSBS0+Cec4kpbCJeEsbUUpdFMTItvanhRP5qNw7ohn7ivGKKM8sCgunoSLEoUwVpUVWKuqIxKsG/JznKS7oEGWk22yuVuPUpofVvExiaLkGK8OBE0QwsmuCkYWn7ifimJlhSZzmv8UaRItFlGSFj95IOSzIxLMGlYB4iFnKusTAVfzrYycWhGRxxMBS6MP8cfkLBr8JOd0plbRfNXaMTte8rCeVRGC1lDuFvsR1ZEHnZDuwZjW3zNQXGWYE6ZvbWorDjQDA9ZiqCiLInkS/gMJ5bfmQ2zOdDS7HpSgMbtbKxmDnKoaLa4akRP01K9dlE3x+yRcQ0pNVcFuRO3Qivodu2OVKqUdHs+hWK1r/RBzBqkffM1YfnsEs/fN/o1rgUMDXMnHmCeBRWtVDyTM66I8J0V9C4TlUEOwuSFtFsZxRA3wV+mVN6lcapQHEC5vdZ28p31TD2JeEmLBCQGIOqAsheu1SoqfTHSl/Hb91YM/N/qXahLGl8NuL42BMYLGp8c+z/eHk9Exj267wSJBiH4NXkQNULlF+ib6NlPWWRj+h7app29zaYTRD9d8Az3+/u8hLb2w/PyuvcTdiqI6xKHLT0NVyRV4CALUQpLilsniLGuqrL20Idxw/S1aVPMxM10mznZN8/5zDTd0Kwihysu/N61oPwUB8mboe9gv5lro4EFVWRGa5x+0pEIn24XRi7K9Ke25iyB8ODTZgQgB1sZbSJKDr9UOJ9uEplPUHLq74Z5QJXj9y6+cuDcsUEQQUBnRBH2jMkJKuRSh8SBT6b2wY9ZUbWW74g8yQegCRBFBQFV9x3mb5iiddIEkoRHXylUL4QcEm1Z0zODzBYk8FgVEBAGb7z1zKD6TmZBkGgpJ+KtXRI2jjlGiObLmGk8XxHu0AkCEAVWU9crpTKkogvpnSbjSvxapDX9hReGBQDQi/qBnC1EH1L4fWqfj9GiF0uXau5aE+oxJ7W+6Y5hUUQWqNDQhPr/HRkRakNA6QffJMz2VQVn1lqUk1L0KugA011HUEm0mtiEhgVAaorBNcAs2muWbf6vBpv5REnL7CXMIKRcJTNOoHkQNAk1JUN4ZvRUJ3IKlca2+d6/as7qEasNLEmo7C/JXiV43TgqhJMuVkQiIRraKmzWPCa7CCCICqIzhvVxLcgr7p/cegFAqnz74NKborP1WdlhUnemWrIIIdcRa2kFi4JEcp1TVggjrHn3Q6qbcJcPayk1CNNyJFiT0FFcb0eq/dNFV/mGEMhgm176/uP25SuqWRcdvHk7YQrQHqHzRVdaYlsqi9HfoH6T2W7Fa81U4oe7rQq6gNwWHJZwghLIorR8YQbGalZTN3QuhnikFmBJD58ac8vARRhqhEbut2YY+Cc1UMLa/2LENo0fLLwW0VCM0+oA+OPZH2M51YyPWf1gGSBJflel2jDRa4fqSRmr7whFmEQThKozQTubTRmT175/7Jx7R93wga1G/6wa4OQvD0+H10ix61keMpWH2EMpW1Foqlt9y11BjiLBeaTKccbXobziwtbeP+p7CHgb5NLoviq3ASfci0IVoyrYJae30/BkrU1XG6+RmzCMTz0uFTxPilxqzCYYgSvcC9/ORwoF+KLcFcuNBtr/fz+aqmxzAUcURfmnA3KI1XaJ3GFEOd66lLah0m1CNWu1Bor15KhsbD3AWcwv/GQRrPqgjap+mde/xzam5eQ0NRKiOhHi+LPml4vNIMT/0hugDE14YUaqpJ8KK7jZRqq0vQYRKTd1ndtXGDT66iTm+b50GXjaEEeXvcrCk+qNVN25GfFBL5bzPuail3EjHuVAaEY8iIEsWIKKcA7uObvBasZrFE5hQrni7EgEpP8elNL71UmxNBkGUDzvm+fXw3oy4IKFa9HF8W1w+4jram3vWvFFAc2dK7csobASRqw2zjYewWRI+wvmLea5m3C5NvgnCA/53ByDcis089Q/aZKd7VV6z7gQTartYS+iiEC3Tnms0eu5b4KvK0Aao/hKgFUlz5d+hHUTEtWiL2D2WPotvVkVW7c0nSpqrkpzG4Ln3hO4fOlvw+Z6mFX/qB/Q8jZubxsgpuydgrTBCfToWnbTrsigj2h0JkWvgrvYPMZPvacHn55tWlIhUn6oml4yUEwnGyK7QXPel8R6M0MwZFK/P5V2DjO+vxjHfs9MWPPeAET/S24JtRDmhbeXeSNI4/jOX4QxAnNDOarlMkvYUxw1YTukIOj32tmALUR5o0IYTWI5mETghoWfPTZ6JL71qjsfTKJ/Ws4bdIKppNifOC5rakxkHofij8x4E77yojqcBB1M1kvkW6ZvhplkBc0QyLa39fSchYXdUI5YP77SojokC49rkbqd/F0K1ov47AufbjKCgg/rziOeBXS4DFWXXrYprAw1K7VOEhA/XiOYMhpKTtcq/ge+IqtYs8FyinK+t2KjNT1CIKatiE2Hfm64jewYKC90tgSkaZftLqlQs+V2jca90dTw6029Rll/jpCnqGhpCW8eXIhv9lJ9Dr63iyKOU0Xz/uB92e+KMqC4jnD2vKG+mPWe7W3bucEntUxEdcd49CUcCt18rq9vjMs57RskUTFGx+jM7qN6IOm8x2zMzD0XYdRF3IlItiD8JZ5USo5HKL/ufnD+Ew/WnLsYZ0lme7aJ/GuH8z3LP8Tw+Nc/jz9CtkRtFvp3+6YqKtKn/dcXiTlJ4O7fJpLMHQ2Llp5l/jiF4tWa60mx7NBFxM7MXC5twVmMNh/K1JXMipEuAsGuUyJiFa+d0NcIZJTRDcl/OZzHDuKdMJww4XDINoRuEcC5W39zCNAhnMsMwE3qb+bxn0RNbtwWahLMYTlt3sLXy6s/AJvJWzor23QjTH07p0knYzjIzPbHuX5vdHSXW4SSLMOg84njFvl/OvivIFek3egHulbUJJz3YtIcZkDAwPGGUwgobZ1b3roH3A0KEk70wKPjuPE9ShNEKBXQUu8NykuMpcj83TIge5xu1gCjYXbIT3DJlSMwndh/w5K55hC8hdRBOrStSuBO6CCd2LzeeDQC/sXtSQTYcT1mBE07p5mpslPEQTufiY8gdDSJUZyhGLuzqgnASTuOSKzuxTAdCR7a00QhwQW4XQt+pm+8L9WUc8RGOHZF7U6p4CSPf0aKvCvdnVPESmpmnRiZeFQ0iFIo61uHGr6KBhGP1wqlnFO1AuAjLr/9hYQ9/xYMJx+jduD2ZzoTjW5xy+qKvEI7tKl334dKXCBfHERlGmoenMAwnHJGTytAlizcJF6dxdEZ00el9wkXc31HCl8VzVPxNwkUEpw//oOCLav0QfvvOWR5sJF4nXCRQMpUPCcs6p4F9gbC0/t/pjRzeXBqAsJX37lPCdp4sGT0SLha/cGqjAYXmwV5ML4SlbfwkI7cCgYYnXCytNEkD8t1fUtA3CZ9pkj7Cx3beO4MGIlws0iz8IrtX+ejNe73SgISC8Taoror2+/NXYlBCMasarj+K/veOfvZFKMacU2gSlE5C+en18aWRPggX5eVVwSlVwoTTzHPnWqj0RCj8nFNwWpwAvNzOUPSq9EYo5G+N38QZLqKI9bujiy59EgpJr3n4/axQ49H82ifeondCIcdix4OvjtXpxKd2RW/KqaR/wlI2qwdh4Y1Z3qlLHqv3LDsmwxCWkvyedjnz3AQsGo6xfHf67b/tpAxH+JRos7383PLySmRa3qBcSflf8TPJs5/LdpiWa2RgQilRsknjbVGsSimKbZxurDSWA8l/ahKafzBrzV0AAAAASUVORK5CYII="
        />
      ),
      company: "Tech Corp",
      role: ["Editor", "User"],
      status: "Ac",
    },
  ];

  const dummy = {
    status: (item: any) => <AssignUser className="w-56" />,
  };

  const handleOutsideClick = (event: MouseEvent) => {
    if (
      filterMenuRef.current &&
      !filterMenuRef.current.contains(event.target as Node)
    ) {
      setOpenFilterBox(false);
    }
    if (
      actionMenuRef.current &&
      !actionMenuRef.current.contains(event.target as Node)
    ) {
      setOpenActionBox(false);
    }
  };

  const SuccessToast = () => {
    setTimeout(() => {
      Toast.success("This is success message");
    }, 1000);
  };

  const handleCompaniesModal = () => {
    setOpenCompaniesModal(!openCompaniesModal);
  };

  const handleConnect = () => {
    setOpenCompaniesModal(false);
    setOpenDrawer(true);
  };

  const handleFilterBox = () => {
    setOpenFilterBox(!openFilterBox);
  };

  const handleActionBox = () => {
    setOpenActionBox(!openActionBox);
  };

  const handleDeactivateModal = () => {
    setOpenDeactivateModal(!openDeactivateModal);
  };

  const handleDisconnectModal = () => {
    setOpenDisconnectModal(!openDisconnectModal);
  };

  const handleRemoveModal = () => {
    setOpenRemoveModal(!openRemoveModal);
  };

  const actionButton: any = (
    <button type="button" onClick={handleActionBox}>
      <ActionIcon />
    </button>
  );

  const action = [actionButton]

  const actionarry: any = [
    "add","edit","delete"
  ]
  

  return (
    <>
      {/* Toast */}
      <div className="z-50">
        <Toast position="top_center" />
      </div>

      {/* Create companies section */}
      <div className="main flex items-center justify-between w-full px-5 py-[15px] bg-[#F6F6F6]">
        <div className="text-[#333] text-base font-bold">
          <span>Manage Companies</span>
        </div>
        <div className="flex items-center">
          <div className="cursor-pointer z-10" onClick={handleFilterBox}>
            <Tooltip position="bottom" content="Filter">
              <FilterIcon />
            </Tooltip>
          </div>
          <Button
            type="submit"
            variant="btn-primary"
            className="rounded-[300px]"
            onClick={handleCompaniesModal}
          >
            <span className="flex items-center justify-center text-[14px]">
              <AddIcon />
              <span className="text-[14px] font-bold px-1">CREATE COMPANY</span>
            </span>
          </Button>
        </div>
      </div>

      {/*  Create Company Popup */}
      <CompaniesModal
        onOpen={openCompaniesModal}
        onClose={() => setOpenCompaniesModal(false)}
        onConnect={handleConnect}
      />

      {/*  Drawer */}
      <Drawer onOpen={openDrawer} onClose={() => setOpenDrawer(false)} />

      {/* Drawer Overlay */}
      <DrawerOverlay isOpen={openDrawer} onClose={() => setOpenDrawer(false)} />

      {/* Deactivate Modal Popup */}
      {openDeactivateModal && (
        <div>
          <Modal
            isOpen={handleDeactivateModal}
            onClose={handleDeactivateModal}
            size="md"
          >
            <ModalTitle>
              <div className="py-3 px-4 font-bold">Deactivate</div>
              <div className="" onClick={handleDeactivateModal}>
                <Close variant="medium" />
              </div>
            </ModalTitle>
            <ModalContent>
              <div className="p-2 mb-3">
                Are you sure you want to deactivate.
              </div>
            </ModalContent>
            <ModalAction>
              <div>
                <Button
                  className="rounded-full btn-sm font-semibold mx-2 my-3 !w-16 !h-[36px]"
                  variant="btn-outline-primary"
                  onClick={handleDeactivateModal}
                >
                  No
                </Button>
              </div>
              <div onClick={SuccessToast}>
                <Button
                  className="rounded-full btn-sm font-semibold mx-2 my-3 !w-16 !h-[36px]"
                  variant="btn-primary"
                  onClick={handleDeactivateModal}
                >
                  Yes
                </Button>
              </div>
            </ModalAction>
          </Modal>
        </div>
      )}

      {/* Disconnect Modal Popup */}
      {openDisconnectModal && (
        <Modal
          isOpen={handleDisconnectModal}
          onClose={handleDisconnectModal}
          width="352px"
        >
          <ModalTitle>
            <div className="py-3 px-4 font-bold">Disconnect</div>
            <div className="" onClick={handleDisconnectModal}>
              <Close variant="medium" />
            </div>
          </ModalTitle>
          <ModalContent>
            <div className="p-2 mb-3">
              Are you sure you want to disconnect the company with accounting
              tool ?
            </div>
          </ModalContent>
          <ModalAction>
            <div>
              <Button
                className="rounded-full btn-sm font-semibold mx-2 my-3 !w-16 !h-[36px]"
                variant="btn-outline-primary"
                onClick={handleDisconnectModal}
              >
                No
              </Button>
            </div>
            <div onClick={SuccessToast}>
              <Button
                className="rounded-full btn-sm font-semibold mx-2 my-3 !w-16 !h-[36px]"
                variant="btn-primary"
                onClick={handleDisconnectModal}
              >
                Yes
              </Button>
            </div>
          </ModalAction>
        </Modal>
      )}

      {/* Remove Modal Popup */}
      {openRemoveModal && (
        <Modal
          isOpen={handleRemoveModal}
          onClose={handleRemoveModal}
          width="352px"
        >
          <ModalTitle>
            <div className="py-3 px-4 font-bold">Remove</div>
            <div className="" onClick={handleRemoveModal}>
              <Close variant="medium" />
            </div>
          </ModalTitle>
          <ModalContent>
            <div className="p-2 mb-3">
              Are you sure you want to remove the Company.
            </div>
          </ModalContent>
          <ModalAction>
            <div>
              <Button
                className="rounded-full btn-sm font-semibold mx-2 my-3 !w-16 !h-[36px]"
                variant="btn-outline-error"
                onClick={handleRemoveModal}
              >
                No
              </Button>
            </div>
            <div onClick={SuccessToast}>
              <Button
                className="rounded-full btn-sm font-semibold mx-2 my-3 !w-16 !h-[36px]"
                variant="btn-error"
                onClick={handleRemoveModal}
              >
                Yes
              </Button>
            </div>
          </ModalAction>
        </Modal>
      )}

      {/* For Filter menu */}
      <div ref={filterMenuRef}>
        <div className="flex absolute right-52 z-10 -mt-4">
          <div
            className={`${
              openFilterBox
                ? "visible flex justify-center items-center "
                : "hidden"
            } w-fit h-auto border border-lightSilver rounded-md bg-white shadow-md`}
          >
            <div className="w-[458px] h-auto">
              <ul>
                <li className="flex flex-row justify-between items-center px-4 py-3 border-b border-b-lightSilver">
                  <div className="text-black text-[20px] font-[500]">
                    Filter
                  </div>
                  <div onClick={handleFilterBox}>
                    <Close variant="medium" />
                  </div>
                </li>
                <li className="p-3">
                  <MultiSelect
                    id={""}
                    defaultValue="All"
                    label="Company"
                    options={options}
                    onSelect={() => {}}
                    type="checkbox"
                  />
                </li>
                <li className="p-3">
                  <MultiSelect
                    id={""}
                    defaultValue="All"
                    label="Accounting Tool"
                    options={options}
                    onSelect={() => {}}
                    type="checkbox"
                  />
                </li>
                <li className="p-3">
                  <MultiSelect
                    id={""}
                    defaultValue="All"
                    label="Assign User"
                    options={options}
                    onSelect={() => {}}
                    type="checkbox"
                  />
                </li>
                <li className="flex flex-row justify-end items-center mt-10 px-4 py-3 border-t border-[#D8D8D8]">
                  <div>
                    <Button
                      onClick={handleFilterBox}
                      className="rounded-full btn-sm mx-2 font-bold"
                      variant="btn-outline-primary"
                    >
                      CANCEL
                    </Button>
                  </div>
                  <div onClick={SuccessToast}>
                    <Button
                      className="rounded-full btn-sm mx-2 font-bold"
                      variant="btn-primary"
                      onClick={handleFilterBox}
                    >
                      APPLY
                    </Button>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* For Action menu */}
      <div ref={actionMenuRef}>
        <div className="flex absolute mt-24 right-12">
          {openActionBox && (
            <div className="visible flex justify-center items-center w-fit h-auto border border-lightSilver rounded-md bg-white shadow-md">
              <div className="w-40 h-auto">
                <ul className="w-40">
                  <li
                    className="flex w-auto h-8 px-5 py-2 hover:bg-lightGray hover:bg-[#ecf7f2] cursor-pointer"
                    onClick={() => setOpenDrawer(true)}
                  >
                    <div className="flex text-sm font-normal justify-center items-center">
                      Edit
                    </div>
                  </li>
                  <li
                    className="flex w-auto h-8 px-5 py-2 hover:bg-lightGray hover:bg-[#ecf7f2] cursor-pointer"
                    onClick={handleDeactivateModal}
                  >
                    <div className="flex  text-sm font-normal justify-center items-center">
                      Deactivate
                    </div>
                  </li>
                  <li
                    className="flex w-auto h-8 px-5 py-2 hover:bg-lightGray hover:bg-[#ecf7f2] cursor-pointer"
                    onClick={handleDisconnectModal}
                  >
                    <div className="flex  text-sm font-normal justify-center items-center">
                      Disconnect
                    </div>
                  </li>
                  <li
                    className="flex w-auto h-8 px-5 py-2 hover:bg-lightGray hover:bg-[#ecf7f2] cursor-pointer"
                    onClick={handleRemoveModal}
                  >
                    <div className="flex  text-sm font-normal justify-center items-center">
                      Remove
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Table Seaction */}
      <Table
        className={"!h-[440px]"}
        data={jsondata}
        headers={headers}
        actions={action}
        actionHeading=" "
        getRowId={(jsonData: any) => {
          jsonData.id;
        }}
        actionDesc={actionarry}
        JsxComponents={dummy}
        sticky
        sortable
        action
        selected
      />
    </>
  );
};

export default ManageCompanies;
