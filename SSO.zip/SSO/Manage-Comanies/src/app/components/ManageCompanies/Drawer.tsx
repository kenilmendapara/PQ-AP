import { useState } from "react";

// Lib components
import { Button, Close, Select, Avatar,Tel, TextField, Toast } from "next-ts-lib";
// import Image from "next/image";
// import BiImage from "../../assets/Images/Frame 26085797.png";

// icons
import EditIcon from "@/app/assets/icons/EditIcon";

interface FormData {
  id: number;
  companyName: string;
  entityType: string;
  address: string;
  country: string;
  state: string;
  city: string;
  postalCode: number;
  phoneNumber: number;
  email: string;
  deletedFile: number;
}

const options = [
  { label: "Option 1", value: "option 1" },
  { label: "Option 2", value: "option 2" },
  { label: "Option 3", value: "option 3" },
];

const Drawer = ({ onOpen, onClose }: any) => {
  const [userData, setUserData] = useState<FormData[]>([
    {
      id: 1,
      companyName: "technomark",
      entityType: "IT Company",
      address: "Ahmdabad",
      country: "India",
      state: "Gujrat",
      city: "Ahmdabad",
      postalCode: 77667,
      phoneNumber: 6576576767,
      email: "tech@gmail.com",
      deletedFile: 30,
    },
  ]);

  const initialFormData = {
    id: 0,
    companyName: "",
    entityType: "",
    address: "",
    country: "",
    state: "",
    city: "",
    postalCode: 0,
    phoneNumber: 0,
    email: "",
    deletedFile: 0,
  };
  // console.log("userData", userData);

  const [formData, setFormData] = useState<FormData>(initialFormData);
  const [imagePreview, setImagePreview] = useState<string>("");
  // const [selectedFile, setSelectedFile] = useState(null);
  // const [fileName, setFileName] = useState("");

  const handleSaveData = () => {
    userData.push(formData);
    setTimeout(() => {
      Toast.success("This is success message");
    }, 1000);
  };

  const onUploadImage = (e: any) => {
    if (e.target?.files && e.target.files[0]) {
      const file = e.target.files[0];
      // setSelectedFile(file);
      // setFileName(file.name);
      const reader = new FileReader();
      reader.onload = function (e) {
        const result = e.target?.result;
        if (result && typeof result === "string") {
          setImagePreview(result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleEditIconClick = () => {
    const fileInput = document.getElementById("imageUpload");
    fileInput && fileInput.click();
  };
  if (!onOpen) return null;

  return (
    <>
      {/* Toast */}
      <div className="z-50">
        <Toast position="top_center" />
      </div>
      {/*  Drawer */}
      <div
        className={`fixed right-0 top-0 h-screen overflow-y-auto lg:w-5/12 text-black transform bg-white z-30 ${
          onOpen ? "translate-x-0" : "translate-x-full"
        } transition-transform duration-500 ease-in-out`}
      >
        <div className="flex justify-between py-[13px] border-b-[1px] border-[#D8D8D8]">
          <div className="text-black text-[18px] mx-6 font-bold">
            Add Company
          </div>
          <div onClick={onClose} className="mx-3">
            <Close variant="medium" />
          </div>
        </div>
        <form onSubmit={handleSaveData}>
          <div className="mx-6">
            <div className="relative flex mt-5">
              <Avatar
                variant="large"
                className="!opacity-100"
                imageUrl={imagePreview}
              />
              <div
                className="absolute bottom-0 left-11 cursor-pointer bg-[#EEF4F8] rounded p-0.5"
                onClick={handleEditIconClick}
              >
                <EditIcon/>
              </div>
              <input
                type="file"
                id="imageUpload"
                accept=".png, .jpg, .jpeg"
                className="hidden"
                onChange={onUploadImage}
              />
            </div>
            <div className=" text-black text-[16px] font-bold mt-7">
              Company Details
            </div>
            <div className="grid lg:grid-cols-2 md:grid-cols-1 mt-1">
              <div className="lg:w-56 md:w-full">
                <TextField
                  label="Company Name"
                  className=""
                  type="text"
                  id="company_name"
                  getValue={(value: any) =>
                    setFormData({ ...formData, companyName: value })
                  }
                  validate
                ></TextField>
              </div>
              <div className="lg:w-56 md:w-full lg:mx-6 md:mx-0">
                <Select
                  id=""
                  className="!pt-[2px]"
                  type="icons"
                  options={options}
                  label="Entity Type"
                  onSelect={(value: any) =>
                    setFormData({ ...formData, entityType: value })
                  }
                  required
                />
              </div>
            </div>
            <div className="text-black text-[16px] font-bold mt-7">
              Address Details
            </div>
            <div className="mt-2">
              <TextField
                label="Address"
                className="!pt-0"
                type="text"
                id="address"
                getValue={(value: any) =>
                  setFormData({ ...formData, address: value })
                }
                validate
              ></TextField>
            </div>
            <div className="grid lg:grid-cols-2 md:grid-cols-1 lg:mt-4 md:mt-2">
              <div className="lg:w-56 md:w-full">
                <Select
                  id={formData.id.toString()}
                  type="icons"
                  options={options}
                  label="Country"
                  onSelect={(value: any) =>
                    setFormData({ ...formData, country: value })
                  }
                  required
                />
              </div>
              <div className="lg:w-56 md:w-full lg:mx-5 md:mx-0">
                <Select
                  id={formData.id.toString()}
                  type="icons"
                  options={options}
                  label="State"
                  onSelect={(value: any) =>
                    setFormData({ ...formData, state: value })
                  }
                  required
                />
              </div>
            </div>
            <div className="grid lg:grid-cols-2 md:grid-cols-1 lg:mt-4 md:mt-2">
              <div className="lg:w-56 md:w-full">
                <Select
                  id={formData.id.toString()}
                  type="icons"
                  options={options}
                  label="City"
                  onSelect={(value: any) =>
                    setFormData({ ...formData, city: value })
                  }
                  required
                />
              </div>
              <div className="lg:w-56 md:w-full lg:mx-5 md:mx-0">
                <TextField
                  type="icons"
                  label="Zip/Postal Code"
                  getValue={(value: any) =>
                    setFormData({ ...formData, postalCode: value })
                  }
                  validate
                />
              </div>
            </div>
            <div className="grid lg:grid-cols-2 md:grid-cols-1 lg:mt-4">
              <div className="lg:w-56 md:w-full md:mt-2 !pt-[2px]">
                <Tel
                  className="lg:!pt-1.5"
                  validate
                  required
                  label="Phone Number"
                  countryCode
                  getValue={(value: any) =>
                    setFormData({ ...formData, phoneNumber: value })
                  }
                />
              </div>
              <div className="lg:w-56 md:w-full lg:mx-5 md:mt-2 md:mx-0">
                <TextField
                  type="icons"
                  label="Email Address"
                  getValue={(value: any) =>
                    setFormData({ ...formData, email: value })
                  }
                  validate
                />
              </div>
            </div>
            <div className=" text-black text-[16px] font-bold mt-7">
              Other Details
            </div>
            <div className="grid lg:grid-cols-2 md:grid-cols-1 mt-1">
              <div className="lg:w-56 md:w-full">
                <TextField
                  label="Delete File in Days"
                  className="!pt-0"
                  type="text"
                  id="delete"
                  validate
                  getValue={(value: any) =>
                    setFormData({ ...formData, email: value })
                  }
                ></TextField>
              </div>
            </div>
          </div>
          <div className="w-full flex justify-end mt-8 border-t-[1px] py-3.5 px-2 border-[#D8D8D8] bottom-0">
            <div onClick={onClose}>
              <Button
                className="rounded-full btn-sm font-semibold mx-2 !w-24 !h-[36px]"
                variant="btn-outline-primary"
              >
                CANCEL
              </Button>
            </div>
            <div onClick={onClose}>
              <Button
                type="submit"
                className="rounded-full btn-sm mx-2 font-semibold !w-20 !h-[36px]"
                variant="btn-primary"
                // onClick={SuccessToast}
              >
                SAVE
              </Button>
            </div>
          </div>
        </form>
      </div>
    </>
  );
};

export default Drawer;
