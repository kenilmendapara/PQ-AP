import React, { MouseEventHandler, useEffect, useRef, useState } from "react";

// lib components
import {
  Button,
  Close,
  TextField,
  Toast,
  Tooltip,
  Typography,
} from "next-ts-lib";

// icons
import FilterIcon from "@/app/assets/icons/FilterIcon";
import SearchIcon from "@/app/assets/icons/SearchIcon";

type FilterContentType = {
  heading?: string;
  submitBtnText?: string;
  resetBtnText?: string;
  element: React.ReactNode | JSX.Element;
};

type ManageProps = {
  manageFor: string;
  filter?: boolean;
  filterContent?: FilterContentType;
  search?: boolean;
  buttonText?: string;
  onClick?: MouseEventHandler<HTMLButtonElement>;
  children: React.ReactNode;
};

const options = [
  { label: "Xero", value: "Xero" },
  { label: "Intacct", value: "Intacct" },
  { label: "QuickBooks Online", value: "QuickBooks Online" },
];

const Manage = ({
  manageFor,
  filter,
  filterContent,
  search,
  buttonText,
  children,
  onClick,
}: ManageProps) => {
  
  const searchRef = useRef<HTMLDivElement>(null);
  const [searching, setSearching] = useState(false);

  useEffect(() => {
    const handleOutsideClick = (event: MouseEvent) => {
      if (
        searchRef.current &&
        !searchRef.current.contains(event.target as Node)
      ) {
        setSearching(false);
      }
    };
    window.addEventListener("click", handleOutsideClick);
    return () => {
      window.removeEventListener("click", handleOutsideClick);
    };
  }, []);

  return (
    <>
      <div className="h-10 mx-5 my-[15px] flex justify-between items-center">
        <Typography type="h4">Manage {manageFor}</Typography>
        <div className="flex items-center gap-5">
          <div>
            <Button
              variant="btn-primary"
              className="rounded-full"
              onClick={onClick}
            >
            </Button>
          </div>
        </div>
      </div>
      <div>{children}</div>
    </>
  );
};

export default Manage;

const Filter = ({
  element,
  heading,
  resetBtnText,
  submitBtnText,
}: FilterContentType) => {
  const filterRef = useRef<HTMLDivElement>(null);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const handleOutsideClick = (event: MouseEvent) => {
      if (
        filterRef.current &&
        !filterRef.current.contains(event.target as Node)
      ) {
        setOpen(false);
      }
    };

    window.addEventListener("click", handleOutsideClick);

    return () => {
      window.removeEventListener("click", handleOutsideClick);
    };
  }, []);

  const handleFilter = () => {
    setOpen(!open);
  };
  const SuccessToast = () => {
    Toast.success("This is success message", "", 1000);
  };

  return (
    <div
      ref={filterRef}
      className="relative cursor-pointer"
      onClick={handleFilter}
    >
      <Tooltip position="top" content="Filter">
        <FilterIcon />
      </Tooltip>
      {open && (
        <div className="flex absolute top-10 -right-5 z-10">
          <div
            className={` flex justify-center items-center w-fit h-auto border border-lightSilver rounded-md bg-white shadow-md animate-fade-in-down_1s_ease-in-out`}
          >
            <div className="w-[458px] h-auto">
              <div className="w-[458px]">
                <div className="flex flex-row justify-between items-center px-4 py-3 border-b border-b-lightSilver">
                  <div className="text-black text-[20px] font-[500]">
                    {heading ? heading : "Filter"}
                  </div>
                  <div onClick={handleFilter}>
                    <Close variant="medium" />
                  </div>
                </div>
                {element}
                <div className="flex flex-row justify-end items-center mt-10 px-4 py-3 border-t border-[#D8D8D8]">
                  <div>
                    <Button
                      onClick={handleFilter}
                      className="rounded-full btn-sm mx-2 font-bold"
                      variant="btn-outline-primary"
                    >
                      {resetBtnText ? resetBtnText : "CANCEL"}
                    </Button>
                  </div>
                  <div onClick={SuccessToast}>
                    <Button
                      className="rounded-full btn-sm mx-2 font-bold"
                      variant="btn-primary"
                      onClick={handleFilter}
                    >
                      {submitBtnText ? submitBtnText : "APPLY"}
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};