"use client";
import { Button } from "next-ts-lib";
//styles
import "next-ts-lib/dist/index.css";

const page = () => {
  return (
    <div className="flex flex-col items-center gap-7">
      <span className="text-4xl">This is main page!!!</span>
      <div className="border rounded-md">
        <Button
          className="rounded-md"
          onClick={() => (window.location.href = "./manage/companies")}
        >
          Redirect to companies page
        </Button>
      </div>
    </div>
  );
};

export default page;
